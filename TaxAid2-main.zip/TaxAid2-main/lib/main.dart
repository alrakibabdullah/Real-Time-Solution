
import 'package:demo/screens/about_us.dart';
import 'package:demo/screens/appointment2.dart';
import 'package:demo/screens/appointment.dart';
import 'package:demo/screens/blogs.dart';
import 'package:demo/screens/book_1.dart';
import 'package:demo/screens/book_2.dart';
import 'package:demo/screens/calender.dart';
import 'package:demo/screens/details.dart';
import 'package:demo/screens/client/client_login.dart';
import 'package:demo/screens/lawer/lawer_login.dart';
import 'package:demo/screens/lawer/lawer_registration.dart';
import 'package:demo/screens/lawer/lawer_signup.dart';
import 'package:demo/screens/our_team.dart';
import 'package:demo/screens/profile.dart';
import 'package:demo/screens/services.dart';
import 'package:demo/screens/client/client_signup.dart';
import 'package:demo/screens/splash.dart';
import 'package:demo/screens/tab_bar.dart';
import 'package:demo/screens/testimonials.dart';
import 'package:demo/screens/client/clien_registration.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

void main()async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        
        primarySwatch: Colors.blue,
      ),
      home: AboutUsScreen()
    );
  }
}

