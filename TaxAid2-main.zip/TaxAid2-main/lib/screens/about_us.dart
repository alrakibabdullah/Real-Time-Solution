import 'package:flutter/material.dart';

class AboutUsScreen extends StatelessWidget {
  const AboutUsScreen({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.grey,
       appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.grey,
        elevation: 0,
        title: Text("About us"),
       ),
       body: Column(
        children: [
          Text(
            "Welcome to TaxAid Law",
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w700,
              decoration: TextDecoration.underline,
              decorationThickness: 2
              
            ),
          )
        ],
       )







      //  Container(
      //   margin: EdgeInsets.symmetric(horizontal: 10),
      //   width: double.infinity,
      //   height: MediaQuery.of(context).size.height,
      //   decoration: BoxDecoration(
      //     color: Colors.white,
      //     borderRadius: BorderRadius.circular(10)
      //   ),
      //   child: Column(
      //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
      //     children: [
      //       Container(
      //         padding: EdgeInsets.only(top: 10,left: 15),
      //         width: double.infinity,
      //         height: 40,
      //         decoration: BoxDecoration(
      //         color: Colors.grey.withOpacity(0.3),
      //         borderRadius: BorderRadius.circular(10),
      //       ),
      //        child: Text(
      //         "Who we are?",
      //         style: TextStyle(
      //           fontSize: 18
      //         ),
      //       ),
      //       ),
      //       Text(
      //         "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Utenim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliqulp exea commodo consequat."
      //       ),
      //        Container(
      //         width: double.infinity,
      //         height: 110,
      //           child: ListView.separated(
      //             scrollDirection: Axis.horizontal,
      //             itemBuilder: (BuildContext,index){
      //               return  Container(
      //               width: 120,
      //               height: 100,
      //               color: Colors.teal,
      //               child: Image.asset("assets/facebook.png",scale: 1,),
                       
      //                 );
      //             }, 
      //             separatorBuilder: (BuildContext,index){
      //               return SizedBox(width: 20,);
      //             }, 
      //             itemCount: 7
      //           ),
      //         ),
      //         Text(
      //         "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Utenim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliqulp exea commodo consequat."
      //       ),
      //       Text(
      //         "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Utenim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliqulp exea commodo consequat."
      //       ),
      //       Row(
      //         mainAxisAlignment: MainAxisAlignment.spaceAround,
      //         children: [
      //           Column(
      //             children: [
      //               Icon(Icons.emoji_emotions_outlined,color: Colors.redAccent,),
      //               Text(
      //                 "253",
      //                 style: TextStyle(
      //                   fontSize: 18,
      //                   fontWeight: FontWeight.w700
      //                 ),
      //               ),
      //               Text(
      //                 "Cases Attended",
      //                 style: TextStyle(
                       
      //                 ),
      //               )
      //             ],
      //           ),
      //             Column(
      //             children: [
      //               Icon(Icons.check_circle_outline,color: Colors.redAccent,),
      //               Text(
      //                 "253",
      //                 style: TextStyle(
      //                   fontSize: 18,
      //                   fontWeight: FontWeight.w700
      //                 ),
      //               ),
      //               Text(
      //                 "Cases Attended",
      //                 style: TextStyle(
                       
      //                 ),
      //               )
      //             ],
      //           ),
      //             Column(
      //             children: [
      //               Icon(Icons.card_travel,color: Colors.redAccent,),
      //               Text(
      //                 "253",
      //                 style: TextStyle(
      //                   fontSize: 18,
      //                   fontWeight: FontWeight.w700
      //                 ),
      //               ),
      //               Text(
      //                 "Cases Attended",
      //                 style: TextStyle(
                       
      //                 ),
      //               )
      //             ],
      //           ),
      //         ],
      //       ),
      //       SizedBox(height: 10,)
      //     ],
      //   ),
      //  ), 
      ),
    );
  }
}