

import 'package:demo/screens/about_us.dart';
import 'package:demo/screens/blogs.dart';
import 'package:demo/screens/book_1.dart';
import 'package:demo/screens/our_team.dart';
import 'package:demo/screens/profile.dart';
import 'package:demo/screens/services.dart';
import 'package:demo/screens/tab_bar.dart';
import 'package:demo/screens/testimonials.dart';
import 'package:flutter/material.dart';

class AppointmentScreen extends StatefulWidget {
  const AppointmentScreen({ Key? key }) : super(key: key);

  @override
  State<AppointmentScreen> createState() => _AppointmentScreenState();
}

class _AppointmentScreenState extends State<AppointmentScreen> {
  final GlobalKey<ScaffoldState> _globalKey = new GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        
         key: _globalKey,
        drawer: Drawer(
          backgroundColor: Colors.black,
          child:Column(
            children: [
              ListTile(
                title:  Text(
                  "Hey Sam,",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24
                  ),
                ),
                trailing: IconButton(
                  onPressed: (){
                     Navigator.push(context, MaterialPageRoute(builder: (_)=>UserProfileScreen()));
                  }, 
                  icon: Icon(Icons.arrow_forward_ios,color: Colors.white,)
                ),
              ),
               ListTile(
                onTap: (){
                   Navigator.push(context, MaterialPageRoute(builder: (_)=>AppointmentScreen()));
                },
                title:  Text(
                  "Home",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18
                  ),
                ),
                leading: Icon(Icons.home,color: Colors.redAccent,),
                
              ),
              ListTile(
                title:  Text(
                  "Appointments",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18
                  ),
                ),
                leading: Icon(Icons.calendar_today_sharp,color: Colors.redAccent,),
                trailing: CircleAvatar(
                  backgroundColor: Colors.redAccent,
                  radius: 8,
                  child: Text(
                    "1",
                     style: TextStyle(
                    color: Colors.white,
    
                  ),
                  ),
                ),
              ),
              ListTile(
                onTap: (){
                   Navigator.push(context, MaterialPageRoute(builder: (_)=>ServicesScreen()));
                },
                title:  Text(
                  "Our Services",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18
                  ),
                ),
                leading: Icon(Icons.card_travel_outlined,color: Colors.redAccent,),
                
              ),
              ListTile(
                onTap: (){
                   Navigator.push(context, MaterialPageRoute(builder: (_)=>AboutUsScreen()));
                },
                title:  Text(
                  "About Us",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18
                  ),
                ),
                leading: Icon(Icons.person,color: Colors.redAccent,),
                
              ),
              ListTile(
                onTap: (){
                   Navigator.push(context, MaterialPageRoute(builder: (_)=>OurTeamScreen()));
                },
                title:  Text(
                  "Our Team",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18
                  ),
                ),
                leading: Icon(Icons.group,color: Colors.redAccent,),
                
              ),
              ListTile(
                onTap: (){
                   Navigator.push(context, MaterialPageRoute(builder: (_)=>TestimonialScreen()));
                },
                title:  Text(
                  "Testimonials",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18
                  ),
                ),
                leading: Icon(Icons.thumb_up_sharp,color: Colors.redAccent,),
                
              ),
              ListTile(
                onTap: (){
                   Navigator.push(context, MaterialPageRoute(builder: (_)=>BlogsScreen()));
                },
                title:  Text(
                  "Read Blogs",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18
                  ),
                ),
                leading: Icon(Icons.pageview,color: Colors.redAccent,),
                
              ),
              ListTile(
                title:  Text(
                  "Change Language",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18
                  ),
                ),
                leading: Icon(Icons.language,color: Colors.redAccent,),
                
              ),
              ListTile(
                title:  Text(
                  "Chat with us",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18
                  ),
                ),
                leading: Icon(Icons.message,color: Colors.redAccent,),
                
              ),
              Container(
                margin: EdgeInsets.symmetric(horizontal: 15),
                  width: double.infinity,
                  height: 30,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20)
                  ),
                  child: ElevatedButton(
                  onPressed: (){
                  }, 
                  child: Text(
                    "Buy this app",
                    style: TextStyle(
    
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    primary: Colors.redAccent
                  ),
                ),
                ),
                ListTile(
                title:  Text(
                  "Developed by:",
                  style: TextStyle(
                    color: Colors.redAccent,
                    fontSize: 18
                  ),
                ),
              ),
            ],
          )
        ),
        backgroundColor: Colors.grey,
          appBar: AppBar(
            automaticallyImplyLeading: false,
            backgroundColor: Colors.grey,
            elevation: 0,
           
            title: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text(
                  "Tax"
                ),
                 Text(
                  "Aid",
                  style: TextStyle(
                    color: Colors.redAccent
                  ),
                ),
              ],
            ),
            actions: [
              IconButton(
                onPressed: (){}, 
                icon: Icon(Icons.notification_important_outlined)
              )
            ],
          ),
          body: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "We've",
                      style: TextStyle(
                        color: Colors.white
                      ),
                    ),
                    SizedBox(height: 10,),
                    Text(
                  """QUALIFIED
ATTORNEYS""",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20
                  ),
                ),
                 SizedBox(height: 15,),
                Text(
                  """Lorem ipsum dolor sit amet,
conseruer dolor ituy scwamet""",
                  style: TextStyle(
                    color: Colors.white,
    
                  ),
                ),
                  ],
                ),
    
                Container(
                  width: double.infinity,
                  height: 100,
                  child: ListView(
                    
                    scrollDirection: Axis.horizontal,
                    children: [
                      InkWell(
                        onTap: (){
                         _globalKey.currentState!.openDrawer(); 
                        },
                        child: Container(
                          height: 100,
                          width: 100,
                         decoration: BoxDecoration(
                           color: Colors.white,
                           borderRadius: BorderRadius.circular(10)
                         ),
                         child: Column(
                           mainAxisAlignment: MainAxisAlignment.spaceAround,
                           children: [
                            Icon(Icons.menu,color: Colors.redAccent,),
                            
                              Text(
                              "View all",
                              style: TextStyle(
                                color: Colors.redAccent
                              ),
                            ),
                           ],
                         ),
                        ),
                      ),
                      SizedBox(width: 10,),
                       InkWell(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (_)=>ServicesScreen()));
                        },
                        child: Container(
                          height: 100,
                          width: 100,
                         decoration: BoxDecoration(
                           color: Colors.white,
                           borderRadius: BorderRadius.circular(10)
                         ),
                         child: Column(
                           mainAxisAlignment: MainAxisAlignment.spaceAround,
                           children: [
                             Icon(Icons.card_travel_sharp,color: Colors.redAccent,),
                              Text(
                              "Services",
                              style: TextStyle(
                                color: Colors.redAccent
                              ),
                            ),
                           ],
                         ),
                        ),
                      ),
                      SizedBox(width: 10,),
                        InkWell(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (_)=>OurTeamScreen()));
                        },
                        child: Container(
                          height: 100,
                          width: 100,
                         decoration: BoxDecoration(
                           color: Colors.white,
                           borderRadius: BorderRadius.circular(10)
                         ),
                         child: Column(
                           mainAxisAlignment: MainAxisAlignment.spaceAround,
                           children: [
                             Icon(Icons.group,color: Colors.redAccent,),
                              Text(
                              "Our Team",
                              style: TextStyle(
                                color: Colors.redAccent
                              ),
                            ),
                           ],
                         ),
                        ),
                      ),
                      SizedBox(width: 10,),
                       InkWell(
                        onTap: (){
                           Navigator.push(context, MaterialPageRoute(builder: (_)=>AboutUsScreen()));
                        },
                        child: Container(
                          height: 100,
                          width: 100,
                         decoration: BoxDecoration(
                           color: Colors.white,
                           borderRadius: BorderRadius.circular(10)
                         ),
                         child: Column(
                           mainAxisAlignment: MainAxisAlignment.spaceAround,
                           children: [
                             Icon(Icons.person_sharp,color: Colors.redAccent,),
                              Text(
                              "About",
                              style: TextStyle(
                                color: Colors.redAccent
                              ),
                            ),
                           ],
                         ),
                        ),
                      ),
                    ],
                  )
                ),
                 Container(
                  width: double.infinity,
                  height: 56,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20)
                  ),
                  child: ElevatedButton(
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (_)=>BookAppointmentScreen()));
                  }, 
                  child: Text(
                    "Book an appointment",
                    style: TextStyle(
                      fontSize: 18
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    primary: Colors.redAccent
                  ),
                ),
                ),
              ],
            ),
          ),
          
        
      ),
    );
  }
}