
import 'package:demo/screens/appointment.dart';
import 'package:demo/screens/my_appoinments.dart';
import 'package:flutter/material.dart';

class AppointmentScreen2 extends StatelessWidget {
  const AppointmentScreen2({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          SizedBox(),
          Column(
            children: [
              CircleAvatar(
                backgroundColor: Colors.white,
                radius: 30,
                child: Icon(Icons.calendar_month,color: Colors.redAccent,),
              ),
              SizedBox(height: 15,),
              Text(
                  "Appointment booked !",
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.white
                  ),
                ),
                SizedBox(height: 15,),
                 Text(
                  """Your appointment has been
     booked with TaxAid""",
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white
                  ),
                ),
            ],
          ),
          Column(
            children: [
              Container(
                width: double.infinity,
                height: 56,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20)
                ),
                child: ElevatedButton(
                onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (_)=>MyAppoinmentsScreen()));
                }, 
                child: Text(
                  "View all Appointments",
                  style: TextStyle(
                    fontSize: 18
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  primary: Colors.redAccent
                ),
              ),
              ),
              SizedBox(height: 10,),
              Container(
                width: double.infinity,
                height: 56,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20)
                ),
                child: ElevatedButton(
                onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (_)=>AppointmentScreen()));
                }, 
                child: Text(
                  "Back to Home",
                  style: TextStyle(
                    fontSize: 18,
                    color: Colors.redAccent
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  primary: Colors.white
                ),
              ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}