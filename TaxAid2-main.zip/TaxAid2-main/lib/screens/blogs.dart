import 'package:flutter/material.dart';

class BlogsScreen extends StatelessWidget {
  const BlogsScreen({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        title: Text(
          "Blogs",
          style: TextStyle(
            color: Colors.black
          ),
        ),
      ),
      body: Column(
        children: [
          SizedBox(height: 5,),
          Expanded(
            child: ListView.separated(
              itemBuilder: (BuildContext,index){
                return  Container(
                  color: Colors.white,
                  child: Row(
                    children: [
                      Container(
                        width: 100,
                        height: 100,
                        color: Colors.teal,
                        padding: EdgeInsets.symmetric(horizontal: 10),
                        child: Image.asset("assets/facebook.png"),
                      ),
                      SizedBox(width: 10,),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: MediaQuery.of(context).size.width/1.5,

                            child: Text(
                             "Journal of Legal Methodology,Policy and Governance:Rolling Submisssions",
                             style: TextStyle(
                               fontSize: 18
                            ),
                            ),
                          ),
                          SizedBox(height: 10,),
                          Text(
                            "Criminal Lawyer",
                            style: TextStyle(
                              color: Colors.grey
                        ),
                        ),
                        ],
                      ),
                     
                    ],
                  ),
                );
              }, 
              separatorBuilder: (BuildContext,index){
                return SizedBox(height: 5,);
              }, 
              itemCount: 7
            ),
          ),
        ],
      ),
    );
  }
}