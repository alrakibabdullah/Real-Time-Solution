import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:demo/screens/appointment.dart';
import 'package:demo/screens/appointment2.dart';
import 'package:demo/screens/book_2.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class BookAppointmentScreen extends StatefulWidget {
  const BookAppointmentScreen({ Key? key }) : super(key: key);

  @override
  State<BookAppointmentScreen> createState() => _BookAppointmentScreenState();
}

class _BookAppointmentScreenState extends State<BookAppointmentScreen> {
bool _value1 = false;
bool _value2 = false;
bool _value3 = false;
bool _value4 = false;
bool _value5 = false;
 sendUserDataToClient() async {
    final FirebaseAuth _auth = FirebaseAuth.instance;
    var currentUser = _auth.currentUser;
   
        
  
   
    CollectionReference _collectionRef =
        FirebaseFirestore.instance.collection("appoinments");
      
        
         return _collectionRef.doc(currentUser!.email).
         set({
        "name":_value1
        

      
    })
      ..then((value) => 
      Navigator.push(
              context, MaterialPageRoute(builder: (_) => AppointmentScreen2())))
          .catchError((error) => print("something is wrong. $error"));
          
      
   
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      appBar: AppBar(
        elevation: 0,
        automaticallyImplyLeading: false,
        backgroundColor: Colors.grey,
         
        title:  Text(
        "Book Appointment",
        style: TextStyle(
          color: Colors.white,
          fontSize: 18
        ),
      ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  "Select Attorney",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18
                  ),
                ),
                Expanded(
                  child: Divider(
                    thickness: 0.5,
                    color: Colors.white,
                  ),
                ),
                CircleAvatar(
                  backgroundColor: Colors.white,
                  radius: 6,
                ),
                Expanded(
                  child: Divider(
                    thickness: 0.5,
                    color: Colors.white,
                  ),
                ),
                CircleAvatar(
                  backgroundColor: Colors.white,
                  radius: 6,
                )
              ],
            ),
            Container(
              width: double.infinity,
              height: 400,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15)
              ),
              child: Column(
                children: [
                  ListTile(
                    leading: CircleAvatar(
                      radius: 20,
                    ),
                    title: Text(
                    "Jack Williamson",
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 18
                    ),
                  ), 
                  subtitle:Text(
                    "Criminal Lawyer",
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 12
                    ),
                  ), 
                  trailing: InkWell(
                    onTap: (){
                      setState(() {
                        _value1=!_value1;
                        _value2 =false;
                        _value3 =false;
                        _value4 =false;
                        _value5 =false;
                      });
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        // border: Border.all(color: Colors.grey)
                      ),
                      child: _value1?
                      Container(
                        decoration: BoxDecoration(
                          border: Border.all(width: 2,color: Colors.redAccent),
                          shape: BoxShape.circle
                        ),
                        child: Icon(
                          Icons.circle,
                          color: Colors.redAccent,
                          size: 15,
                        ),
                      ):Icon(Icons.circle_outlined,size: 17,),
                    ),
                  ), 
                  ),
                   ListTile(
                    leading: CircleAvatar(
                      radius: 20,
                    ),
                    title: Text(
                    "Peter Davis",
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 18
                    ),
                  ), 
                  subtitle:Text(
                    "Corporate Lawyer",
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 12
                    ),
                  ), 
                  trailing: InkWell(
                    onTap: (){
                      setState(() {
                        _value1=false;
                        _value2 =!_value2;
                        _value3 =false;
                        _value4 =false;
                        _value5 =false;
                      });
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        // border: Border.all(color: Colors.grey)
                      ),
                      child: _value2?
                      Container(
                        decoration: BoxDecoration(
                          border: Border.all(width: 2,color: Colors.redAccent),
                          shape: BoxShape.circle
                        ),
                        child: Icon(
                          Icons.circle,
                          color: Colors.redAccent,
                          size: 15,
                        ),
                      ):Icon(Icons.circle_outlined,size: 17,),
                    ),
                  ), 
                  ),
                  ListTile(
                    leading: CircleAvatar(
                      radius: 20,
                    ),
                    title: Text(
                    "Jon Snow",
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 18
                    ),
                  ), 
                  subtitle:Text(
                    "Criminal Lawyer",
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 12
                    ),
                  ), 
                  trailing: InkWell(
                    onTap: (){
                      setState(() {
                        _value1=false;
                        _value2 =false;
                        _value3 =!_value3;
                        _value4 =false;
                        _value5 =false;
                      });
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        // border: Border.all(color: Colors.grey)
                      ),
                      child: _value3?
                      Container(
                        decoration: BoxDecoration(
                          border: Border.all(width: 2,color: Colors.redAccent),
                          shape: BoxShape.circle
                        ),
                        child: Icon(
                          Icons.circle,
                          color: Colors.redAccent,
                          size: 15,
                        ),
                      ):Icon(Icons.circle_outlined,size: 17,),
                    ),
                  ), 
                  ),
                  ListTile(
                    leading: CircleAvatar(
                      radius: 20,
                    ),
                    title: Text(
                    "Emilia Clarke",
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 18
                    ),
                  ), 
                  subtitle:Text(
                    "Corporate Lawyer",
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 12
                    ),
                  ), 
                  trailing: InkWell(
                    onTap: (){
                      setState(() {
                        _value1=false;
                        _value2 =false;
                        _value3 =false;
                        _value4 =!_value4;
                        _value5 =false;
                      });
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        // border: Border.all(color: Colors.grey)
                      ),
                      child: _value4?
                      Container(
                        decoration: BoxDecoration(
                          border: Border.all(width: 2,color: Colors.redAccent),
                          shape: BoxShape.circle
                        ),
                        child: Icon(
                          Icons.circle,
                          color: Colors.redAccent,
                          size: 15,
                        ),
                      ):Icon(Icons.circle_outlined,size: 17,),
                    ),
                  ), 
                  ),
                  ListTile(
                    leading: CircleAvatar(
                      radius: 20,
                      backgroundColor: Colors.redAccent,
                      child: Icon(Icons.person),
                    ),
                    title: Text(
                    "Any",
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 18
                    ),
                  ), 
                  subtitle:Text(
                    "Firm will advice",
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 12
                    ),
                  ), 
                  trailing: InkWell(
                    onTap: (){
                      setState(() {
                        _value1=false;
                        _value2 =false;
                        _value3 =false;
                        _value4 =false;
                        _value5 =!_value5;
                      });
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        // border: Border.all(color: Colors.grey)
                      ),
                      child: _value5?
                      Container(
                        decoration: BoxDecoration(
                          border: Border.all(width: 2,color: Colors.redAccent),
                          shape: BoxShape.circle
                        ),
                        child: Icon(
                          Icons.circle,
                          color: Colors.redAccent,
                          size: 15,
                        ),
                      ):Icon(Icons.circle_outlined,size: 17,),
                    ),
                  ), 
                  )
                ],
              ),
            ),
            Container(
                width: double.infinity,
                height: 56,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20)
                ),
                child: ElevatedButton(
                onPressed: (){
                  // Navigator.push(context, MaterialPageRoute(builder: (_)=>BookAppoinmentScreen2()));
                  sendUserDataToClient();
                }, 
                child: Text(
                  "Next",
                  style: TextStyle(
                    fontSize: 18
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  primary: Colors.redAccent
                ),
              ),
              ),
          ],
        ),
      ),
    );
  }
}