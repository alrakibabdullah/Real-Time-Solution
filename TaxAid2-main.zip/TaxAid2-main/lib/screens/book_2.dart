import 'package:demo/screens/appointment.dart';
import 'package:demo/screens/appointment2.dart';
import 'package:flutter/material.dart';

class BookAppoinmentScreen2 extends StatefulWidget {
  const BookAppoinmentScreen2({ Key? key }) : super(key: key);

  @override
  State<BookAppoinmentScreen2> createState() => _BookAppoinmentScreen2State();
}

class _BookAppoinmentScreen2State extends State<BookAppoinmentScreen2> {
   TextEditingController _dateController = TextEditingController();
  TextEditingController _timeController = TextEditingController();
TimeOfDay selectedTime = TimeOfDay.now();
 bool _value1 = false;
bool _value2 = false;
bool _value3 = false;
bool _value4 = false;
bool _value5 = false;
bool _value6 = false;




  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.grey,
        appBar: AppBar(
           elevation: 0,
          backgroundColor: Colors.grey,
          title:  Text(
          "Book Appointment",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18
          ),
        ),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    
                   
                    CircleAvatar(
                      backgroundColor: Colors.redAccent,
                      radius: 6,
                    ),
                    Expanded(
                      child: Divider(
                        thickness: 0.5,
                        color: Colors.redAccent,
                      ),
                    ),
                    Text(
                      "Select Case Type",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18
                      ),
                    ),
                     Expanded(
                      child: Divider(
                        thickness: 0.5,
                        color: Colors.white,
                      ),
                    ),
                    CircleAvatar(
                      backgroundColor: Colors.white,
                      radius: 6,
                    )
                  ],
                ),
                SizedBox(height: 10,),
                Container(
                  width: double.infinity,
                  height: 400,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15)
                  ),
                  child: Column(
                    children: [
                      ListTile(
                        leading: CircleAvatar(
                          backgroundColor: Colors.grey.withOpacity(0.3),
                          radius: 20,
                          child: Icon(Icons.home,color: Colors.redAccent,),
                        ),
                        title: Text(
                        "Income Tax Services",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 18
                        ),
                      ), 
                      trailing: InkWell(
                        onTap: (){
                          setState(() {
                            _value1=!_value1;
                            _value2 =false;
                            _value3 =false;
                            _value4 =false;
                            _value5 =false;
                            _value6 = false;
                          });
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            // border: Border.all(color: Colors.grey)
                          ),
                          child: _value1?
                          Container(
                            decoration: BoxDecoration(
                              border: Border.all(width: 2,color: Colors.redAccent),
                              shape: BoxShape.circle
                            ),
                            child: Icon(
                              Icons.circle,
                              color: Colors.redAccent,
                              size: 15,
                            ),
                          ):Icon(Icons.circle_outlined,size: 17,),
                        ),
                      ), 
                      ),
                       ListTile(
                        leading: CircleAvatar(
                          backgroundColor: Colors.grey.withOpacity(0.3),
                          radius: 20,
                          child: Icon(Icons.card_travel,color: Colors.redAccent,),
                        ),
                        title: Text(
                        "VAT Services",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 18
                        ),
                      ), 
                      trailing: InkWell(
                        onTap: (){
                          setState(() {
                            _value1=false;
                            _value2 =!_value2;
                            _value3 =false;
                            _value4 =false;
                            _value5 =false;
                            _value6 = false;
                          });
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            // border: Border.all(color: Colors.grey)
                          ),
                          child: _value2?
                          Container(
                            decoration: BoxDecoration(
                              border: Border.all(width: 2,color: Colors.redAccent),
                              shape: BoxShape.circle
                            ),
                            child: Icon(
                              Icons.circle,
                              color: Colors.redAccent,
                              size: 15,
                            ),
                          ):Icon(Icons.circle_outlined,size: 17,),
                        ),
                      ), 
                      ),
                      ListTile(
                        leading: CircleAvatar(
                           backgroundColor: Colors.grey.withOpacity(0.3),
                          radius: 20,
                          child: Icon(Icons.add_box,color: Colors.redAccent,),
                        ),
                        title: Text(
                        "RJSC Company Registration",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 18
                        ),
                      ), 
                      trailing: InkWell(
                        onTap: (){
                          setState(() {
                            _value1=false;
                            _value2 =false;
                            _value3 =!_value3;
                            _value4 =false;
                            _value5 =false;
                            _value6 = false;
                          });
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            // border: Border.all(color: Colors.grey)
                          ),
                          child: _value3?
                          Container(
                            decoration: BoxDecoration(
                              border: Border.all(width: 2,color: Colors.redAccent),
                              shape: BoxShape.circle
                            ),
                            child: Icon(
                              Icons.circle,
                              color: Colors.redAccent,
                              size: 15,
                            ),
                          ):Icon(Icons.circle_outlined,size: 17,),
                        ),
                      ), 
                      ),
                      ListTile(
                        leading: CircleAvatar(
                           backgroundColor: Colors.grey.withOpacity(0.3),
                          radius: 20,
                          child: Icon(Icons.person_add,color: Colors.redAccent,),
                        ),
                        title: Text(
                        "Partnership Firm",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 18
                        ),
                      ),  
                      trailing: InkWell(
                        onTap: (){
                          setState(() {
                            _value1=false;
                            _value2 =false;
                            _value3 =false;
                            _value4 =!_value4;
                            _value5 =false;
                            _value6 = false;
                          });
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            // border: Border.all(color: Colors.grey)
                          ),
                          child: _value4?
                          Container(
                            decoration: BoxDecoration(
                              border: Border.all(width: 2,color: Colors.redAccent),
                              shape: BoxShape.circle
                            ),
                            child: Icon(
                              Icons.circle,
                              color: Colors.redAccent,
                              size: 15,
                            ),
                          ):Icon(Icons.circle_outlined,size: 17,),
                        ),
                      ), 
                      ),
                      ListTile(
                        leading: CircleAvatar(
                          backgroundColor: Colors.grey.withOpacity(0.3),
                          radius: 20,
                          child: Icon(Icons.group,color: Colors.redAccent,),
                        ),
                        title: Text(
                        "Trademark Registration",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 18
                        ),
                      ), 
             
                      trailing: InkWell(
                        onTap: (){
                          setState(() {
                            _value1=false;
                            _value2 =false;
                            _value3 =false;
                            _value4 =false;
                            _value5 =!_value5;
                            _value6 = false;
                          });
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            // border: Border.all(color: Colors.grey)
                          ),
                          child: _value5?
                          Container(
                            decoration: BoxDecoration(
                              border: Border.all(width: 2,color: Colors.redAccent),
                              shape: BoxShape.circle
                            ),
                            child: Icon(
                              Icons.circle,
                              color: Colors.redAccent,
                              size: 15,
                            ),
                          ):Icon(Icons.circle_outlined,size: 17,),
                        ),
                      ), 
                      ),
                     ListTile(
                        leading: CircleAvatar(
                          backgroundColor: Colors.grey.withOpacity(0.3),
                          radius: 20,
                          child: Icon(Icons.error,color: Colors.redAccent,),
                        ),
                        title: Text(
                        "Other",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 18
                        ),
                      ), 
                      trailing: InkWell(
                        onTap: (){
                          setState(() {
                            _value1=false;
                            _value2 =false;
                            _value3 =false;
                            _value4 =false;
                            _value5 =false;
                            _value6 = !_value6;
                          });
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            // border: Border.all(color: Colors.grey)
                          ),
                          child: _value6?
                          Container(
                            decoration: BoxDecoration(
                              border: Border.all(width: 2,color: Colors.redAccent),
                              shape: BoxShape.circle
                            ),
                            child: Icon(
                              Icons.circle,
                              color: Colors.redAccent,
                              size: 15,
                            ),
                          ):Icon(Icons.circle_outlined,size: 17,),
                        ),
                      ), 
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 10,),
                TextFormField(
                    style: TextStyle(color: Colors.black),
                    readOnly: true,
                    controller: _dateController,
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.white,
                      hintText: "Select Date ",
                        hintStyle: TextStyle(
                          color: Colors.black,
                        ),
                      suffixIcon: IconButton(
                        onPressed: () => _selectDateFromPicker(context),
                        icon: Icon(Icons.calendar_today_outlined,
                        color: Colors.redAccent,
                        ),
                      ),
                        border: OutlineInputBorder(    
                      borderRadius: BorderRadius.circular(15),
                    ),
                      disabledBorder: InputBorder.none, 
                  focusedBorder: OutlineInputBorder(
                  borderSide: const BorderSide(),
                    borderRadius: BorderRadius.circular(15.0),
                  ),    
                    ),
                  ),
                  SizedBox(height: 10,),
                   TextFormField(
                    style: TextStyle(color: Colors.black),
                    readOnly: true,
                    controller: _timeController,
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.white,
                      hintText: "Select Time",
                        hintStyle: TextStyle(
                          color: Colors.black,
                        ),
                      
                      suffixIcon: IconButton(
                        onPressed: (){
                           _selectTime(context);
                        },
                        icon: Icon(Icons.alarm,
                        color: Colors.redAccent,
                        ),
                      ),
                        border: OutlineInputBorder( 
                      borderRadius: BorderRadius.circular(15),
                    ),
                      disabledBorder: InputBorder.none,  
                  focusedBorder: OutlineInputBorder(
                  borderSide: const BorderSide(),
                    borderRadius: BorderRadius.circular(15),
                  ),
                      
                    ),
                  ),
                  SizedBox(height: 10,),
                Container(
                    width: double.infinity,
                    height: 56,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20)
                    ),
                    child: ElevatedButton(
                    onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (_)=>AppointmentScreen2()));
                    }, 
                    child: Text(
                      "Next",
                      style: TextStyle(
                        fontSize: 18
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      primary: Colors.redAccent
                    ),
                  ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
  Future<void> _selectTime(BuildContext context) async {          
      final TimeOfDay? timeOfDay = await showTimePicker(
        
        context: context,
        initialTime: selectedTime,
        initialEntryMode: TimePickerEntryMode.dial,
      );
      if(timeOfDay != null && timeOfDay != selectedTime)
        {
          setState(() {
          _timeController.text; selectedTime = timeOfDay;
          // _timeController.text="${selectedTime.hour}:${selectedTime.minute}:${selectedTime.format(context)}";
          _timeController.text="${selectedTime.format(context)}";
          });
        }
  }
  Future<void> _selectDateFromPicker(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: DateTime(DateTime.now().year - 20),
        firstDate: DateTime(DateTime.now().year - 30),
        lastDate: DateTime(DateTime.now().year +20));
    if (picked != null)
      setState(() {
        _dateController.text = "${picked.day}/ ${picked.month}/ ${picked.year}";
      });
  }
}