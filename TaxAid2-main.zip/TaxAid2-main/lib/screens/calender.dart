import 'package:flutter/material.dart';


class CalenderScreen extends StatefulWidget {
   CalenderScreen({ Key? key }) : super(key: key);

  @override
  State<CalenderScreen> createState() => _CalenderScreenState();
}

class _CalenderScreenState extends State<CalenderScreen> {
  TextEditingController _dateController = TextEditingController();
  TextEditingController _timeController = TextEditingController();
TimeOfDay selectedTime = TimeOfDay.now();

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.teal,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(
          "Fixed Your Appoinment",
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[












            // ElevatedButton(
            //     onPressed: () {
            //       _selectTime(context);
            //     },
            //   child: Text("Choose Time"),
            // ),
            // Text("${selectedTime.format(context)}",
            // style: TextStyle(
            //   color: Colors.white
            // ),),
            TextFormField(
                style: TextStyle(color: Colors.red),
                readOnly: true,
                controller: _dateController,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Color(0xffF7F7F7).withOpacity(0.4),
                  hintText: "Select Date ",
                    hintStyle: TextStyle(
                      color: Colors.white,
                    ),
                  
                  suffixIcon: IconButton(
                    onPressed: () => _selectDateFromPicker(context),
                    icon: Icon(Icons.calendar_today_outlined,
                    
                    ),
                  ),
                
                  
                    border: OutlineInputBorder(
                      
                  borderRadius: BorderRadius.circular(27.5),
                ),
                  disabledBorder: InputBorder.none,
                  
              focusedBorder: OutlineInputBorder(
              borderSide: const BorderSide(),
                borderRadius: BorderRadius.circular(25.0),
              ),
                  
                ),
              ),
               TextFormField(
                style: TextStyle(color: Colors.red),
                readOnly: true,
                controller: _timeController,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Color(0xffF7F7F7).withOpacity(0.4),
                  hintText: "Select Time",
                    hintStyle: TextStyle(
                      color: Colors.white,
                    ),
                  
                  suffixIcon: IconButton(
                    onPressed: (){
                       _selectTime(context);
                    },
                    icon: Icon(Icons.alarm,
                    color: Colors.white.withOpacity(0.4),
                    ),
                  ),
          
                
                  
                    border: OutlineInputBorder(
                      
                  borderRadius: BorderRadius.circular(27.5),
                ),
                  disabledBorder: InputBorder.none,
                  
              focusedBorder: OutlineInputBorder(
              borderSide: const BorderSide(),
                borderRadius: BorderRadius.circular(25.0),
              ),
                  
                ),
              ),
                                   
            
          ],
        ),
      ),
    );
  }

 Future<void> _selectTime(BuildContext context) async {          
      final TimeOfDay? timeOfDay = await showTimePicker(
        
        context: context,
        initialTime: selectedTime,
        initialEntryMode: TimePickerEntryMode.dial,
      );
      if(timeOfDay != null && timeOfDay != selectedTime)
        {
          setState(() {
          _timeController.text; selectedTime = timeOfDay;
          // _timeController.text="${selectedTime.hour}:${selectedTime.minute}:${selectedTime.format(context)}";
          _timeController.text="${selectedTime.format(context)}";
          });
        }
  }
  Future<void> _selectDateFromPicker(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: DateTime(DateTime.now().year - 20),
        firstDate: DateTime(DateTime.now().year - 30),
        lastDate: DateTime(DateTime.now().year));
    if (picked != null)
      setState(() {
        _dateController.text = "${picked.day}/ ${picked.month}/ ${picked.year}";
      });
  }
}