import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:demo/screens/client/client_login.dart';
import 'package:demo/screens/client/clien_registration.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class ClientSignUpScreen extends StatefulWidget {
   ClientSignUpScreen({ Key? key }) : super(key: key);

  @override
  State<ClientSignUpScreen> createState() => _ClientSignUpScreenState();
}

class _ClientSignUpScreenState extends State<ClientSignUpScreen> {
  
TextEditingController _emailController=TextEditingController();
TextEditingController _passwordController=TextEditingController();
TextEditingController _nameController = TextEditingController();

   signUp() async {
    try {
      UserCredential userCredential = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(
              email: _emailController.text, password: _passwordController.text);
      var authCredential = userCredential.user;
      print(authCredential!.uid);

      if (authCredential.uid.isNotEmpty) {
        Navigator.push(
            context, MaterialPageRoute(builder: (_) => ClientRegistrationScreen()));
      } else {
        Fluttertoast.showToast(msg: "Something is Wrong");
      }
    } on FirebaseAuthException catch (e) {
      if (e.code == 'weak-password') {
        Fluttertoast.showToast(msg: 'The password provided is too weak.');
      } else if (e.code == 'email-already-in-use') {
        Fluttertoast.showToast(
            msg: 'The account already exists for that email.');
      }
    } catch (e) {
      print(e);
    }
  }







  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.grey,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          backgroundColor: Colors.grey,
          elevation: 0,
          title: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "Tax"
              ),
               Text(
                "Aid",
                style: TextStyle(
                  color: Colors.redAccent
                ),
              ),
            ],
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        InkWell(
                          onTap: (){
                           Navigator.push(context, MaterialPageRoute(builder: (_)=>ClientLogInScreen()));
                          },
                          child: Text(
                            "Login",
                            style: TextStyle(
                              fontSize: 20,
                              color: Colors.white
                            ),
                          ),
                        ),
                        InkWell(
                          onTap: (){
                             Navigator.push(context, MaterialPageRoute(builder: (_)=>ClientSignUpScreen()));
                          },
                          child: Text(
                            "Sign up",
                            style: TextStyle(
                              fontSize: 20,
                              color:Colors.redAccent
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                SizedBox(height: 20,),
                Container(
              padding: EdgeInsets.symmetric(horizontal: 15),
              width: double.infinity,
              height: 300,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20)
              ),
              child: SingleChildScrollView(
                child: Column(
          
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    SizedBox(height: 10,),
                    TextFormField(
                    controller: _nameController,
                      style: TextStyle(color: Colors.black),
                                            
                      decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.white,
                      
                      labelStyle: TextStyle(color: Colors.black,),
                      hintText: "Full Name",
                      hintStyle: TextStyle(
                        color: Colors.black,
                      ),
                    border: OutlineInputBorder(
                      
                      borderSide: BorderSide.none,
                                
                      ),
                      disabledBorder: InputBorder.none,
                        focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide.none,
                        
                      ),                      
                        ),
                      ),
                      Divider(
                        thickness: 1.5,
                        color: Colors.grey,
                      ),
                    TextFormField(
                    controller: _emailController,
                      style: TextStyle(color: Colors.black),
                                            
                      decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.white,
                      
                      labelStyle: TextStyle(color: Colors.black,),
                      hintText: "Email Address",
                      hintStyle: TextStyle(
                        color: Colors.black,
                      ),
                    border: OutlineInputBorder(
                      
                      borderSide: BorderSide.none,
                                
                      ),
                      disabledBorder: InputBorder.none,
                        focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide.none,
                        
                      ),                      
                        ),
                      ),
                      Divider(
                        thickness: 1.5,
                        color: Colors.grey,
                      ),
                    TextFormField(
                    controller: _passwordController,
                      obscureText: true,
                      obscuringCharacter: "*",
                                            
                      decoration: InputDecoration(
                        
                      filled: true,
                      fillColor: Colors.white,
                      
                      labelStyle: TextStyle(color: Colors.black,),
                      hintText: "Password",
                      
                      hintStyle: TextStyle(
                        color: Colors.black,
                      ),
                    border: OutlineInputBorder(
                      borderSide: BorderSide.none,
                                
                      ),
                      disabledBorder: InputBorder.none,
                        focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide.none,
                        
                      ),                      
                        ),
                      ),
                  ],
                ),
              ),
            ),
                SizedBox(height: 20,),
                Container(
                width: double.infinity,
                height: 56,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20)
                ),
                child: ElevatedButton(
                onPressed: (){
                  signUp();
                }, 
                child: Text(
                  "Sign up",
                  style: TextStyle(
                    fontSize: 18
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  primary: Colors.redAccent
                ),
                  ),
                  ),
                  SizedBox(height: 20,),
                  Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                Text(
                "By signing up, you agree to our",
                style: TextStyle(
        
                  color: Colors.white
                ),
                  ),
                  SizedBox(width: 5,),
                  Text(
                "terms & conditions",
                style: TextStyle(
        
                  color: Colors.redAccent
                ),
                  ),
                ],
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}