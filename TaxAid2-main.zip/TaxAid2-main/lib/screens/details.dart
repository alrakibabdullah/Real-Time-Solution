import 'package:flutter/material.dart';

class DetailsScreen extends StatelessWidget {
  const DetailsScreen({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.grey,
      
        body: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                width: double.infinity,
                height: 200,
                 decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20)
                  ),
                child: Image.asset("assets/logo.jpg",scale: 5,fit: BoxFit.cover,)
                ),
              Transform.translate(
                offset: Offset(0, -30),
                child: Container(
                  margin: EdgeInsets.symmetric(horizontal: 10),
                  width: double.infinity,
                  height: 400,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10)
                  ),
                  child: SingleChildScrollView(
                    child: Column(
                      // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                         Container(
                        width: double.infinity,
                        height: 65,
                        decoration: BoxDecoration(
                          color: Colors.grey.withOpacity(0.3),
                          borderRadius: BorderRadius.circular(10)
                        ),
                        child: ListTile(
                          title: Text("Jack Williamson"),
                          subtitle: Text("Criminal Lawyer"),
                          trailing:Row(
                            mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.home),
                            Icon(Icons.home),
                            Icon(Icons.home),
                            Icon(Icons.home),
                            
                          ],
                        ) ,
                        ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 15),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            crossAxisAlignment: CrossAxisAlignment.start,
                             children: [
                          SizedBox(height: 10,),
                          Text(
                            "About",
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w700
                            ),
                          ),
                          SizedBox(height: 10,),
                          Text( "Lorem ipsum dolor sit amet, consectetur adipiscing elit, set do eiusmod tempor incididunt ut labore et dolore amgna aliqua.Utenim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip exea commodo consequat."),
                          SizedBox(height: 10,),
                          Text(
                            "Studies",
                             style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w700
                            ),
                          ),
                          SizedBox(height: 10,),
                          Text( "Lorem ipsum dolor sit amet, consectetur adipiscing elit, set do eiusmod tempor incididunt ut labore et dolore amgna aliqua.Utenim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip exea commodo consequat."),
                          SizedBox(height: 10,),
                          Text(
                            "Language Known",
                             style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w700
                            ),
                          ),
                          SizedBox(height: 10,),
                          Text( "Lorem ipsum dolor sit amet, consectetur adipiscing elit, set do eiusmod tempor incididunt ut labore et dolore amgna aliqua.Utenim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip exea commodo consequat.")
                                               ],
                                             ),
                     ),
                     
                      ],
                    ),
                  ),
                ),
              ),
              Container(
              width: double.infinity,
              height: 56,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20)
              ),
              child: ElevatedButton(
              onPressed: (){
                
              }, 
              child: Text(
                "Book an appointment",
                style: TextStyle(
                  fontSize: 18
                ),
              ),
              style: ElevatedButton.styleFrom(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                primary: Colors.redAccent
              ),
            ),
            ),
            ],
          ),
        ),
      ),
    );
  }
}