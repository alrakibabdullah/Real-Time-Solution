import 'package:demo/screens/appointment.dart';
import 'package:demo/screens/lawer/lawer_signup.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:fluttertoast/fluttertoast.dart';

class LawerLoginScreen extends StatefulWidget {
  const LawerLoginScreen({Key? key}) : super(key: key);

  @override
  State<LawerLoginScreen> createState() => _LawerLoginScreenState();
}

class _LawerLoginScreenState extends State<LawerLoginScreen> {
  TextEditingController _emailController=TextEditingController();
  TextEditingController _passwordController=TextEditingController();


logIn() async {
    try {
      UserCredential userCredential = await FirebaseAuth.instance
          .signInWithEmailAndPassword(
              email: _emailController.text, password: _passwordController.text);
      var authCredential = userCredential.user;
      print(authCredential!.uid);

      if (authCredential.uid.isNotEmpty) {
        Navigator.push(
            context, MaterialPageRoute(builder: (_) => AppointmentScreen()));
      } else {
        Fluttertoast.showToast(msg: "Something is Wrong");
      }
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found') {
        Fluttertoast.showToast(msg: 'No user found for that email.');
      } else if (e.code == 'wrong-password') {
        Fluttertoast.showToast(msg: 'Wrong password provided for that user.');
      }
    } catch (e) {
      print(e);
    }
  }





  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.grey,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          backgroundColor: Colors.grey,
          elevation: 0,
          title: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                " Tax"
              ),
               Text(
                "Aid",
                style: TextStyle(
                  color: Colors.redAccent
                ),
              ),
            ],
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    InkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (_)=>LawerLoginScreen()));
                      },
                      child: Text(
                        "Login",
                        style: TextStyle(
                          fontSize: 20,
                          color: Colors.redAccent
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (_)=>LawerSignupScreen()));
                      },
                      child: Text(
                        "Sign up",
                        style: TextStyle(
                          fontSize: 20,
                          color: Colors.white
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 20,),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 15),
                 width: double.infinity,
                 height: 200,
                 decoration: BoxDecoration(
                   color: Colors.white,
                   borderRadius: BorderRadius.circular(20)
                 ),
                 child: Column(
                   crossAxisAlignment: CrossAxisAlignment.end,
                   mainAxisAlignment: MainAxisAlignment.spaceAround,
                   children: [
                     SizedBox(height: 10,),
                     TextFormField(
                      controller: _emailController,
                       style: TextStyle(color: Colors.black),
                                              
                        decoration: InputDecoration(
                        filled: true,
                        fillColor: Colors.white,
                       
                        labelStyle: TextStyle(color: Colors.redAccent,),
                        hintText: "Email Address",
                        hintStyle: TextStyle(
                          color: Colors.black,
                        ),
                      border: OutlineInputBorder(
                        
                        borderSide: BorderSide.none,
                                 
                        ),
                        disabledBorder: InputBorder.none,
                          focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide.none,
                          
                        ),                      
                          ),
                        ),
                        Divider(
                          thickness: 1.5,
                          color: Colors.grey,
                        ),
                     TextFormField(
                      controller: _passwordController,
                       obscureText: true,
                       obscuringCharacter: "*",
                                              
                        decoration: InputDecoration(
                          
                        filled: true,
                        fillColor: Colors.white,
                       
                        labelStyle: TextStyle(color: Colors.red,),
                        hintText: "Password",
                        
                        hintStyle: TextStyle(
                          color: Colors.black,
                        ),
                      border: OutlineInputBorder(
                        borderSide: BorderSide.none,
                                 
                        ),
                        disabledBorder: InputBorder.none,
                          focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide.none,
                          
                        ),                      
                          ),
                        ),
                        Text(
                      "Forgot?",
                      style: TextStyle(
                        fontSize: 20,
                        color: Colors.red
                      ),
                    ),
                   ],
                 ),
                ),
                SizedBox(height: 20,),
                Container(
                width: double.infinity,
                height: 56,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20)
                ),
                child: ElevatedButton(
               onPressed: ()async{
                try {
                   UserCredential userCredential = await FirebaseAuth.instance
                 .signInWithEmailAndPassword(
                 email: _emailController.text, password: _passwordController.text);
                var authCredential = userCredential.user;
                 print(authCredential!.uid);
                  if (authCredential.uid.isNotEmpty) {
                   logIn();
                    
                  } else {
                    print("no");
                  }
                  
                } catch (e) {
                    Fluttertoast.showToast(msg: 'Complete all the fills');
                  
                }
                  
                }, 
                child: Text(
                  "Login",
                  style: TextStyle(
                    fontSize: 18
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  primary: Colors.redAccent
                ),
              ),
              ),
              SizedBox(height: 20,),
              Text(
                "Or Continue with",
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.white
                ),
              ),
              SizedBox(height: 20,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  SizedBox(
                    height: 50,
                    child: ElevatedButton.icon(
                      onPressed: (){}, 
                      icon: Image.asset("assets/facebook.png",scale: 4,), 
                      label: Text(
                      "Facebook",
                      style: TextStyle(
                        fontSize: 18,
                        color: Colors.white
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      primary: Colors.blueAccent
                    ),
                    ),
                  ),
                   SizedBox(
                    height: 50,
                    child: ElevatedButton.icon(
                      onPressed: (){}, 
                      icon: Image.asset("assets/google.png",scale: 4,), 
                      label: Text(
                      "Google",
                      style: TextStyle(
                        fontSize: 18,
                        color: Colors.black
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      primary: Colors.white
                    ),
                    ),
                  ),
                ],
              ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}