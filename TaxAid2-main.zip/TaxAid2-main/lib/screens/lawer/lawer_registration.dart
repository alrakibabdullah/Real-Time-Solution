import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:demo/screens/client/client_login.dart';
import 'package:demo/screens/lawer/lawer_login.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class LawerRegistrationScreen extends StatefulWidget {
  const LawerRegistrationScreen({ Key? key }) : super(key: key);

  @override
  State<LawerRegistrationScreen> createState() => _LawerRegistrationScreenState();
}

class _LawerRegistrationScreenState extends State<LawerRegistrationScreen> {
 TextEditingController _phoneController=TextEditingController();
TextEditingController _nidController=TextEditingController();
TextEditingController _nameController = TextEditingController();
TextEditingController _addressController = TextEditingController();
TextEditingController _designationController = TextEditingController();



   sendUserDataToLawer() async {
       final FirebaseAuth _auth = FirebaseAuth.instance;
    var currentUser = _auth.currentUser;
    CollectionReference _collectionRef =
    FirebaseFirestore.instance.collection("users-form-data-lawer");
         return _collectionRef.doc(currentUser!.email).set({
      "name":_nameController.text,
      "phone":_phoneController.text,
      "designation":_designationController.text,
      "nid":_nidController.text,
      "address": _addressController.text,
    })
      ..then((value) => 
      Navigator.push(
              context, MaterialPageRoute(builder: (_) => LawerLoginScreen())))
          .catchError((error) => print("something is wrong. $error"));
       
    
          
      
  }





  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          backgroundColor: Colors.white,
          elevation: 0,
          title: Text(
            "Registration",
            style: TextStyle(
           color: Colors.black
          ),
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: SingleChildScrollView(
            child: Column(
              children: [
                Text(
                  "Submit your valuable information",
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w700
                  ),
                ),
                SizedBox(height: 30,),
                 Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  SizedBox(height: 10,),
                  TextFormField(
                    controller: _nameController,
                    style: TextStyle(color: Colors.black),
                                          
                    decoration: InputDecoration(
                    filled: true,
                    fillColor: Colors.white,
                    
                    labelStyle: TextStyle(color: Colors.black,),
                    hintText: "Full Name",
                    hintStyle: TextStyle(
                      color: Colors.black,
                    ),
                  border: OutlineInputBorder(
                    
                    borderSide: BorderSide.none,
                              
                    ),
                    disabledBorder: InputBorder.none,
                      focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide.none,
                      
                    ),                      
                      ),
                    ),
                    Divider(
                      thickness: 1.5,
                      color: Colors.grey,
                    ),
                  TextFormField(
                    controller: _phoneController,
                    style: TextStyle(color: Colors.black),
                                          
                    decoration: InputDecoration(
                    filled: true,
                    fillColor: Colors.white,
                    
                    labelStyle: TextStyle(color: Colors.black,),
                    hintText: "Phone Number",
                    hintStyle: TextStyle(
                      color: Colors.black,
                    ),
                  border: OutlineInputBorder(
                    
                    borderSide: BorderSide.none,
                              
                    ),
                    disabledBorder: InputBorder.none,
                      focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide.none,
                      
                    ),                      
                      ),
                    ),
                    Divider(
                      thickness: 1.5,
                      color: Colors.grey,
                    ),
                     TextFormField(
                    style: TextStyle(color: Colors.black),
                    controller: _designationController,                    
                    decoration: InputDecoration(
                    filled: true,
                    fillColor: Colors.white,
                   
                    labelStyle: TextStyle(color: Colors.black,),
                    hintText: "Dasignation",
                    
                    hintStyle: TextStyle(
                      color: Colors.black,
                    ),
                  border: OutlineInputBorder(
                    borderSide: BorderSide.none,
                              
                    ),
                    disabledBorder: InputBorder.none,
                      focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide.none,
                      
                    ),
                      ),
                    ),
                     Divider(
                      thickness: 1.5,
                      color: Colors.grey,
                    ),
                  TextFormField(
                    controller: _nidController,                   
                    decoration: InputDecoration(
                    filled: true,
                    fillColor: Colors.white,
                    
                    labelStyle: TextStyle(color: Colors.black,),
                    hintText: "NID Number",
                    
                    hintStyle: TextStyle(
                      color: Colors.black,
                    ),
                  border: OutlineInputBorder(
                    borderSide: BorderSide.none,
                              
                    ),
                    disabledBorder: InputBorder.none,
                      focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide.none,
                      
                    ),
                      ),
                    ),
                     Divider(
                      thickness: 1.5,
                      color: Colors.grey,
                    ),
                     TextFormField(
                      controller: _addressController,
                    style: TextStyle(color: Colors.black),
                                          
                    decoration: InputDecoration(
                    filled: true,
                    fillColor: Colors.white,
                    
                    labelStyle: TextStyle(color: Colors.black,),
                    hintText: "Address",
                    hintStyle: TextStyle(
                      color: Colors.black,
                    ),
                  border: OutlineInputBorder(
                    
                    borderSide: BorderSide.none,
                              
                    ),
                    disabledBorder: InputBorder.none,
                      focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide.none,
                      
                    ),                      
                      ),
                    ),
                   
                ],
              ),
              SizedBox(height: 20,),
              Container(
              width: double.infinity,
              height: 56,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20)
              ),
              child: ElevatedButton(
              onPressed: (){
               sendUserDataToLawer();
              }, 
              child: Text(
                "Submit",
                style: TextStyle(
                  fontSize: 18
                ),
              ),
              style: ElevatedButton.styleFrom(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                primary: Colors.redAccent
              ),
            ),
            ),
          
              ],
            ),
          ),
        ),
        
      ),
    );
  }
}