

import 'package:flutter/material.dart';

class MyAppoinmentsScreen extends StatelessWidget {
  const MyAppoinmentsScreen({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.grey,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.grey,
          title: Text("My Appoinments"),
        ),
        body:Column(
          children: [
            Expanded(
              child: ListView.separated(
                scrollDirection:Axis.horizontal ,
                  itemBuilder: (BuildContext,index){
                    return   Container(
                padding: EdgeInsets.symmetric(horizontal: 10),
                width: 400,
                height: MediaQuery.of(context).size.height,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10)
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text("IN 2 Days"),
                            IconButton(
                              onPressed: (){}, 
                              icon: Icon(Icons.delete,color: Colors.redAccent,)
                            )
                          ],
                        ),
                        ListTile(
                          leading: CircleAvatar(
                            radius: 15,
                          ),
                          title: Text("Jack Wiliamson"),
                          subtitle: Text("Criminal Lawyer "),
                        ),
                            ListTile(
                          leading: CircleAvatar(
                            backgroundColor: Colors.grey.withOpacity(0.4),
                            radius: 15,
                            child: Icon(Icons.home,color: Colors.redAccent,),
                          ),
                          title: Text(
                            "Appointment for",
                            style: TextStyle(
                              fontSize: 14,
                              
                            ),
                          ),
                          subtitle: Text(
                            "Bank & Finance case ",
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                              color: Colors.black
                            ),
                          ),
                          
                        ),
                            ListTile(
                          leading: CircleAvatar(
                            backgroundColor: Colors.grey.withOpacity(0.4),
                            radius: 15,
                            child: Icon(Icons.calendar_month,color: Colors.redAccent,),
                          ),
                          title: Text(
                            "Appointment Date",
                            style: TextStyle(
                              fontSize: 14,
                              
                            ),
                          ),
                          subtitle: Text(
                            "12 June,2021(Wed) ",
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                              color: Colors.black
                            ),
                          ),
                          
                        ),
                            ListTile(
                          leading: CircleAvatar(
                            backgroundColor: Colors.grey.withOpacity(0.4),
                            radius: 15,
                            child: Icon(Icons.alarm,color: Colors.redAccent,),
                          ),
                          title: Text(
                            "Appointment Time",
                            style: TextStyle(
                              fontSize: 14,
                              
                            ),
                          ),
                          subtitle: Text(
                            "11:00 am ",
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                              color: Colors.black
                            ),
                          ),
                          
                        ),
                        
                      ],
                    ),
                    Container(
                    width: double.infinity,
                    height: 56,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.redAccent,)
                    ),
                    child: OutlinedButton(
                      onPressed: (){}, 
                      child: Text(
                      "Reschedule",
                      style: TextStyle(
                        fontSize: 18,
                        color: Colors.redAccent
                      ),
                    ),
                    ),
                    ),
                  ],
                ),
              ); 
                  }, 
                  separatorBuilder: (BuildContext,index){
                    return SizedBox(width: 10,);
                  }, 
                  itemCount: 7
                ),
            ),
          ],
        ), 

       

      ),
    );
  }
}