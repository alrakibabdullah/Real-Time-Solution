import 'package:demo/screens/details.dart';
import 'package:flutter/material.dart';

class OurTeamScreen extends StatelessWidget {
  const OurTeamScreen({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.grey,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.grey,
          title: Text("Our Team"),
        ),
        body: Container(
          margin: EdgeInsets.symmetric(horizontal: 15),
          width: double.infinity,
          height: MediaQuery.of(context).size.height,
          color: Colors.white,
          child: SingleChildScrollView(
            child: Column(
                children: [
                Container(
                    padding: EdgeInsets.only(top: 10,left: 15),
                    width: double.infinity,
                    height: 40,
                    decoration: BoxDecoration(
                    color: Colors.grey.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(10)
                     ),
                      child: Text(
                    "Whow work for us?",
                    style: TextStyle(
                      fontSize: 18
                    ),
                    ),
                    ),
                    SizedBox(height: 10,),
                  Container(
                    width: double.infinity,
                    height:MediaQuery.of(context).size.height,
                    color: Colors.white,
                    child: ListView.separated(
                      itemBuilder: (BuildContext,index){
                        return  Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Container(
                              width: 100,
                              height: 100,
                              color: Colors.teal,
                              child: Image.asset("assets/facebook.png"),
                            ),
                            Column(
                              children: [
                               Text(
                                "Jack Williamson",
                                style: TextStyle(
                              fontSize: 18
                            ),
                            ),
                             Text(
                                "Criminal Lawyer",
                                style: TextStyle(
                                  color: Colors.grey
                            ),
                            ),
                            Row(
                              children: [
                                Icon(Icons.home),
                                Icon(Icons.home),
                                Icon(Icons.home),
                                Icon(Icons.home),
                                
                              ],
                            )
                              ],
                            ),
                            InkWell(
                              onTap: (){
                                Navigator.push(context, MaterialPageRoute(builder: (_)=>DetailsScreen()));
                              },
                              child: Icon(
                                Icons.arrow_forward_ios,color: Colors.redAccent,
                                ),
                            )
                          ],
                        );
                      }, 
                      separatorBuilder: (BuildContext,index){
                        return SizedBox(height: 10,);
                      }, 
                      itemCount: 7
                    ),
                  ),
                ],
              ),
          ),
        ),
      ),
    );
  }
}