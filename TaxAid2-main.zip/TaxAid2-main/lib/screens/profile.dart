import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:demo/screens/about_us.dart';
import 'package:demo/screens/appointment.dart';
import 'package:demo/screens/blogs.dart';
import 'package:demo/screens/our_team.dart';
import 'package:demo/screens/services.dart';
import 'package:demo/screens/testimonials.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

class UserProfileScreen extends StatefulWidget {
  const UserProfileScreen({ Key? key }) : super(key: key);

  @override
  State<UserProfileScreen> createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen> {

 TextEditingController? nameController;
  TextEditingController? phoneController;
  TextEditingController? addressController;
  TextEditingController? dobController;
  TextEditingController? nidController;
  setDataToTextfieldClient(data){
     SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Column(
                children: [
                  Container(
                    height: 130,
                    width: 130,
                    decoration: BoxDecoration(
                      color: Colors.teal,
                      borderRadius: BorderRadius.circular(10)
                    ),
                  ),
                   Transform.translate(
                offset: Offset(0, -30),
                child: CircleAvatar(
                  radius: 20,
                  backgroundColor: Colors.red,
                  child: IconButton(
                    onPressed: (){}, 
                    icon: Icon(Icons.camera_alt)
                  ),
                ),
              ),
                ],
              ),
             
              Container(
                    padding: EdgeInsets.symmetric(horizontal: 15),
                   width: double.infinity,
                   height: 300,
                   decoration: BoxDecoration(
                     color: Colors.white,
                     borderRadius: BorderRadius.circular(20)
                   ),
                   child: Column(
                     crossAxisAlignment: CrossAxisAlignment.end,
                     mainAxisAlignment: MainAxisAlignment.spaceAround,
                     children: [
                       SizedBox(height: 10,),
                       TextFormField(
                        controller: nameController = TextEditingController(text: data["name"]),
                         style: TextStyle(color: Colors.black),
                                                
                          decoration: InputDecoration(
                          filled: true,
                          fillColor: Colors.white,
                         
                          labelStyle: TextStyle(color: Colors.black,),
                          hintText: "Full Name",
                          hintStyle: TextStyle(
                            color: Colors.black,
                          ),
                        border: OutlineInputBorder(
                          
                          borderSide: BorderSide.none,
                                   
                          ),
                          disabledBorder: InputBorder.none,
                            focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide.none,
                            
                          ),                      
                            ),
                          ),
                          Divider(
                            thickness: 1.5,
                            color: Colors.grey,
                          ),
                       TextFormField(
                        controller: phoneController = TextEditingController(text: data["phone"]),
                         style: TextStyle(color: Colors.black),
                                                
                          decoration: InputDecoration(
                          filled: true,
                          fillColor: Colors.white,
                         
                          labelStyle: TextStyle(color: Colors.black,),
                          hintText: "Phone Number",
                          hintStyle: TextStyle(
                            color: Colors.black,
                          ),
                        border: OutlineInputBorder(
                          
                          borderSide: BorderSide.none,
                                   
                          ),
                          disabledBorder: InputBorder.none,
                            focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide.none,
                            
                          ),                      
                            ),
                          ),
                            Divider(
                            thickness: 1.5,
                            color: Colors.grey,
                          ),
                       TextFormField(
                        controller: dobController=TextEditingController(text:data["dob"]),
                                                
                          decoration: InputDecoration(
                            
                          filled: true,
                          fillColor: Colors.white,
                         
                          labelStyle: TextStyle(color: Colors.black,),
                          hintText: "Date of birth",
                          
                          hintStyle: TextStyle(
                            color: Colors.black,
                          ),
                        border: OutlineInputBorder(
                          borderSide: BorderSide.none,
                                   
                          ),
                          disabledBorder: InputBorder.none,
                            focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide.none,
                            
                          ),                      
                            ),
                          ),
                            Divider(
                            thickness: 1.5,
                            color: Colors.grey,
                          ),
                       TextFormField(
                        controller: nidController=TextEditingController(text:data["nid"]),
                                                
                          decoration: InputDecoration(
                            
                          filled: true,
                          fillColor: Colors.white,
                         
                          labelStyle: TextStyle(color: Colors.black,),
                          hintText: "NID Number",
                          
                          hintStyle: TextStyle(
                            color: Colors.black,
                          ),
                        border: OutlineInputBorder(
                          borderSide: BorderSide.none,
                                   
                          ),
                          disabledBorder: InputBorder.none,
                            focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide.none,
                            
                          ),                      
                            ),
                          ),
                          Divider(
                            thickness: 1.5,
                            color: Colors.grey,
                          ),
                       TextFormField(
                        controller: addressController=TextEditingController(text:data["address"]),
                                                
                          decoration: InputDecoration(
                            
                          filled: true,
                          fillColor: Colors.white,
                         
                          labelStyle: TextStyle(color: Colors.black,),
                          hintText: "Address",
                          
                          hintStyle: TextStyle(
                            color: Colors.black,
                          ),
                        border: OutlineInputBorder(
                          borderSide: BorderSide.none,
                                   
                          ),
                          disabledBorder: InputBorder.none,
                            focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide.none,
                            
                          ),                      
                            ),
                          ),
                     ],
                   ),
                  ),
                  SizedBox(height: 20,),
                  Container(
                  width: double.infinity,
                  height: 56,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20)
                  ),
                  child: ElevatedButton(
                  onPressed: (){
                  }, 
                  child: Text(
                    "Update Profile",
                    style: TextStyle(
                      fontSize: 18
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    primary: Colors.redAccent
                  ),
                ),
                ),
            ],
          ),
        );

  }





  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        drawer: Drawer(
           backgroundColor: Colors.black,
          child:Column(
            children: [
              ListTile(
                title:  Text(
                  "Hey Sam,",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24
                  ),
                ),
                trailing: IconButton(
                  onPressed: (){
                     Navigator.push(context, MaterialPageRoute(builder: (_)=>UserProfileScreen()));
                  }, 
                  icon: Icon(Icons.arrow_forward_ios,color: Colors.white,)
                ),
              ),
               ListTile(
                onTap: (){
                   Navigator.push(context, MaterialPageRoute(builder: (_)=>AppointmentScreen()));
                },
                title:  Text(
                  "Home",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18
                  ),
                ),
                leading: Icon(Icons.home,color: Colors.redAccent,),
                
              ),
              ListTile(
                title:  Text(
                  "Appointments",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18
                  ),
                ),
                leading: Icon(Icons.calendar_today_sharp,color: Colors.redAccent,),
                trailing: CircleAvatar(
                  backgroundColor: Colors.redAccent,
                  radius: 8,
                  child: Text(
                    "1",
                     style: TextStyle(
                    color: Colors.white,
    
                  ),
                  ),
                ),
              ),
              ListTile(
                onTap: (){
                   Navigator.push(context, MaterialPageRoute(builder: (_)=>ServicesScreen()));
                },
                title:  Text(
                  "Our Services",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18
                  ),
                ),
                leading: Icon(Icons.card_travel_outlined,color: Colors.redAccent,),
                
              ),
              ListTile(
                onTap: (){
                   Navigator.push(context, MaterialPageRoute(builder: (_)=>AboutUsScreen()));
                },
                title:  Text(
                  "About Us",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18
                  ),
                ),
                leading: Icon(Icons.person,color: Colors.redAccent,),
                
              ),
              ListTile(
                onTap: (){
                   Navigator.push(context, MaterialPageRoute(builder: (_)=>OurTeamScreen()));
                },
                title:  Text(
                  "Our Team",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18
                  ),
                ),
                leading: Icon(Icons.group,color: Colors.redAccent,),
                
              ),
              ListTile(
                onTap: (){
                   Navigator.push(context, MaterialPageRoute(builder: (_)=>TestimonialScreen()));
                },
                title:  Text(
                  "Testimonials",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18
                  ),
                ),
                leading: Icon(Icons.thumb_up_sharp,color: Colors.redAccent,),
                
              ),
              ListTile(
                onTap: (){
                   Navigator.push(context, MaterialPageRoute(builder: (_)=>BlogsScreen()));
                },
                title:  Text(
                  "Read Blogs",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18
                  ),
                ),
                leading: Icon(Icons.pageview,color: Colors.redAccent,),
                
              ),
              ListTile(
                title:  Text(
                  "Change Language",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18
                  ),
                ),
                leading: Icon(Icons.language,color: Colors.redAccent,),
                
              ),
              ListTile(
                title:  Text(
                  "Chat with us",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18
                  ),
                ),
                leading: Icon(Icons.message,color: Colors.redAccent,),
                
              ),
              Container(
                margin: EdgeInsets.symmetric(horizontal: 15),
                  width: double.infinity,
                  height: 30,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20)
                  ),
                  child: ElevatedButton(
                  onPressed: (){
                  }, 
                  child: Text(
                    "Buy this app",
                    style: TextStyle(
    
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    primary: Colors.redAccent
                  ),
                ),
                ),
                ListTile(
                title:  Text(
                  "Developed by:",
                  style: TextStyle(
                    color: Colors.redAccent,
                    fontSize: 18
                  ),
                ),
              ),
            ],
          )
        ),
        backgroundColor: Colors.grey,
        appBar: AppBar(
          backgroundColor: Colors.grey,
          elevation: 0,
          title: Text("My Profile"),
        ),
      //   body:StreamBuilder(
      //   stream: FirebaseFirestore.instance.collection("users-form-data").doc(FirebaseAuth.instance.currentUser!.email).snapshots(),
      //   builder: (BuildContext context, AsyncSnapshot snapshot){
      //     var data=snapshot.data;
      //     if(data==null){
      //       return Center(child: CircularProgressIndicator());
      //     }
      //     return setDataToTextfieldClient(data);
      //   },
      // )







        
        
      ),
    );
  }
}