import 'package:flutter/material.dart';

class ServicesScreen extends StatelessWidget {
  const ServicesScreen({ Key? key }) : super(key: key);
  

  @override
  Widget build(BuildContext context) {
    final width=MediaQuery.of(context).size.width;
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.grey,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.grey,
          title: Text("Our Services"),
        ),
        
        body: Container(
          margin: EdgeInsets.symmetric(horizontal: 5),
          width: double.infinity,
          height: MediaQuery.of(context).size.height,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10)
          ),
          child: SingleChildScrollView(
            child: width >200?Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: EdgeInsets.only(top: 10,left: 15),
                  width: double.infinity,
                  height: 40,
                  decoration: BoxDecoration(
                  color: Colors.grey.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                    "What we offer?",
                    style: TextStyle(
                      fontSize: 18
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 15,),
                      Text(
                    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Utenim ad minim veniam, quis nostrud exercition ullamco laboris nisi ut aliquip exea commodo consequat"
                  ),
                  SizedBox(height: 15,),
                  Row(
                    children: [
                      CircleAvatar(
                        backgroundColor: Colors.grey.withOpacity(0.7),
                        radius: 20,
                        child: Icon(Icons.card_travel_outlined,color: Colors.redAccent,),
                      ),
                      SizedBox(width: 15,),
                      Text(
                      "Income Tax Services",
                      style: TextStyle(
                        fontSize: 18
                      ),
                    ),
                    ],
                  ),
                  SizedBox(height: 15,),
                  Text(
                     "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Utenim ad minim veniam, quis nostrud exercition ullamco laboris nisi ut aliquip exea commodo consequat"
                  ),
                  SizedBox(height: 15,),
                  Row(
                    children: [
                      CircleAvatar(
                        backgroundColor: Colors.grey.withOpacity(0.7),
                        radius: 20,
                        child: Icon(Icons.card_travel_outlined,color: Colors.redAccent,),
                      ),
                      SizedBox(width: 15,),
                      Text(
                      "VAT Services",
                      style: TextStyle(
                        fontSize: 18
                      ),
                    ),
                    ],
                  ),
                  SizedBox(height: 15,),
                   Text(
                     "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Utenim ad minim veniam, quis nostrud exercition ullamco laboris nisi ut aliquip exea commodo consequat"
                  ),
                  SizedBox(height: 15,),
                  Row(
                    children: [
                      CircleAvatar(
                        backgroundColor: Colors.grey.withOpacity(0.7),
                        radius: 20,
                        child: Icon(Icons.group,color: Colors.redAccent,),
                      ),
                      SizedBox(width: 15,),
                      Text(
                      "RJSC Company Registration",
                      style: TextStyle(
                        fontSize: 18
                      ),
                    ),
                    ],
                  ),
                  SizedBox(height: 15,),
                   Text(
                     "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Utenim ad minim veniam, quis nostrud exercition ullamco laboris nisi ut aliquip exea commodo consequat"
                  ),
                  Row(
                    children: [
                      CircleAvatar(
                        backgroundColor: Colors.grey.withOpacity(0.7),
                        radius: 20,
                        child: Icon(Icons.group,color: Colors.redAccent,),
                      ),
                      SizedBox(width: 15,),
                      Text(
                      "Partnership Firm",
                      style: TextStyle(
                        fontSize: 18
                      ),
                    ),
                    ],
                  ),
                  SizedBox(height: 15,),
                     Row(
                    children: [
                      CircleAvatar(
                        backgroundColor: Colors.grey.withOpacity(0.7),
                        radius: 20,
                        child: Icon(Icons.group,color: Colors.redAccent,),
                      ),
                      SizedBox(width: 15,),
                      Text(
                      "Tradmark Registration",
                      style: TextStyle(
                        fontSize: 18
                      ),
                    ),
                    ],
                  ),
                  
                  
                   

                    ],
                  ),
                ),
                
              ],
            ):Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: Column(
                    children: [
                      SizedBox(height: 15,),
                      Text(
                    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Utenim ad minim veniam, quis nostrud exercition ullamco laboris nisi ut aliquip exea commodo consequat"
                  ),
                  SizedBox(height: 15,),
                  Row(
                    children: [
                      CircleAvatar(
                        backgroundColor: Colors.grey.withOpacity(0.7),
                        radius: 20,
                        child: Icon(Icons.card_travel_outlined,color: Colors.redAccent,),
                      ),
                      SizedBox(width: 15,),
                      Text(
                      "Bank & Finance case",
                      style: TextStyle(
                        fontSize: 18
                      ),
                    ),
                    ],
                  ),
                  SizedBox(height: 15,),
                  Text(
                     "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Utenim ad minim veniam, quis nostrud exercition ullamco laboris nisi ut aliquip exea commodo consequat"
                  ),
                  SizedBox(height: 15,),
                  Row(
                    children: [
                      CircleAvatar(
                        backgroundColor: Colors.grey.withOpacity(0.7),
                        radius: 20,
                        child: Icon(Icons.card_travel_outlined,color: Colors.redAccent,),
                      ),
                      SizedBox(width: 15,),
                      Text(
                      "Corporate Case",
                      style: TextStyle(
                        fontSize: 18
                      ),
                    ),
                    ],
                  ),
                  SizedBox(height: 15,),
                   Text(
                     "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Utenim ad minim veniam, quis nostrud exercition ullamco laboris nisi ut aliquip exea commodo consequat"
                  ),
                  SizedBox(height: 15,),
                  Row(
                    children: [
                      CircleAvatar(
                        backgroundColor: Colors.grey.withOpacity(0.7),
                        radius: 20,
                        child: Icon(Icons.group,color: Colors.redAccent,),
                      ),
                      SizedBox(width: 15,),
                      Text(
                      "Family Case",
                      style: TextStyle(
                        fontSize: 18
                      ),
                    ),
                    ],
                  ),
                  SizedBox(height: 15,),
                   Text(
                     "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Utenim ad minim veniam, quis nostrud exercition ullamco laboris nisi ut aliquip exea commodo consequat"
                  ),

                    ],
                  ),
                ),
          ),
        ),
        
      ),
    );
  }
}