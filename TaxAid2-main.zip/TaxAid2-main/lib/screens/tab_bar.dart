import 'package:demo/screens/about_us.dart';
import 'package:demo/screens/client/client_login.dart';
import 'package:demo/screens/our_team.dart';
import 'package:demo/screens/services.dart';
import 'package:demo/screens/client/client_signup.dart';
import 'package:demo/screens/testimonials.dart';
import 'package:flutter/material.dart';

class TabBarScreen extends StatefulWidget {
  const TabBarScreen({ Key? key }) : super(key: key);

  @override
  State<TabBarScreen> createState() => _TabBarScreenState();
}

class _TabBarScreenState extends State<TabBarScreen> {
  
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: DefaultTabController(
        length: 4,
        child: Scaffold(
          backgroundColor: Colors.black,
           appBar: AppBar(
          title: Text("TabBar"),
        ),
          body: Column(
              children: [
                SizedBox(
                  height: 10,
                ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 5),
                child: TabBar(
                  isScrollable: true,
                  unselectedLabelColor: Colors.white,
                  indicatorSize: TabBarIndicatorSize.tab,
                  indicatorColor: Colors.redAccent,
                   indicator: BoxDecoration(
               
                  color: Colors.redAccent
                  ),
                  
                  
                tabs: [
                 Tab(
                   child: Icon(Icons.card_travel),
                 ), 
                  Tab(
                   child: Icon(Icons.person,),
                 ),   
                  Tab(
                   child:Icon(Icons.group,),
                 ),   
                  Tab(
                   child:Icon(Icons.thumb_up_sharp,),
                 ),
     
                  
             ]
            ),
              ),
            Expanded(
              child: TabBarView(
                children: [
                  ServicesScreen(),
                  AboutUsScreen(),
                  OurTeamScreen(),
                  TestimonialScreen(),
      
                ]
                ),
            )
            ],
           ),
        ),
      ),
    );
  }
}