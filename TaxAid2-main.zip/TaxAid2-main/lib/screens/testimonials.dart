import 'package:flutter/material.dart';

class TestimonialScreen extends StatelessWidget {
  const TestimonialScreen({ Key? key }) : super(key: key);
  

  @override
  Widget build(BuildContext context) {
    
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.grey,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.grey,
          title: Text("Testimonials"),
        ),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15),
          child: Column(
            children: [
              SizedBox(height: 10,),
              Container(
                width: double.infinity,
                height: 50,
                child: Container(
                padding: EdgeInsets.only(top: 10,left: 15),
                width: double.infinity,
                height: 40,
                decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(10),
                  topRight: Radius.circular(10),
                ),
                 ),
                  child: Text(
                "What our cluent says about us?",
                style: TextStyle(
                  fontSize: 18
                ),
                ),
                ),
              ),
              Expanded(
                child: Transform.translate(
                  offset: Offset(0, -10),
                  child: ListView.separated(
                    itemBuilder: (BuildContext,index){
                      return  Column(
                        children: [
                          Container(
                          width: double.infinity,
                          height: MediaQuery.of(context).size.height/2.5,
                          decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          ),
                          child: Column(
                          children: [
                            
                            ListTile(
                              leading: CircleAvatar(),
                              title: Text(
                                "Rirvik Sha"
                              ),
                              subtitle: Text(
                                "Criminal Lawyer"
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 15),
                              child: Text(
                                "Lorem ipsum dolor sit amet, consectetur adipiscing elit, set do eiusmod tempor incididunt ut labore et dolore amgna aliqua.Utenim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip exea commodo consequat."
                              ),
                            )
                          ],
                          ),
                        ),
                        ],
                      );
                    }, 
                    separatorBuilder: (BuildContext,index){
                      return SizedBox(height: 10,);
                    }, 
                    itemCount: 7
                  ),
                ),
              ),
            ],
          ),
        ),
        
      ),
    );
  }
}