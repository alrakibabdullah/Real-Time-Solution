import 'package:demo/screens/client/client_login.dart';
import 'package:demo/screens/lawer/lawer_login.dart';
import 'package:demo/screens/lawer/lawer_signup.dart';
import 'package:demo/screens/client/client_signup.dart';
import 'package:demo/screens/client/clien_registration.dart';
import 'package:demo/screens/lawer/lawer_registration.dart';
import 'package:flutter/material.dart';

class SelectUserScreen extends StatelessWidget {
  const SelectUserScreen({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Column(
          children: [
            Container(
              width: double.infinity,
              height: 300,
              child: Image.asset("assets/logo.jpg",scale: 2,),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25),
              child: Column(
                children: [
                  Container(
                    width: double.infinity,
                    height: 56,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20)
                    ),
                    child: ElevatedButton(
                    onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (_)=>ClientLogInScreen()));
                    }, 
                    child: Text(
                      "Client",
                      style: TextStyle(
                        fontSize: 18
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      primary: Colors.redAccent
                    ),
                  ),
                  ),
                  SizedBox(height: 25,),
                  Container(
                width: double.infinity,
                height: 56,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20)
                ),
                child: ElevatedButton(
                onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (_)=>LawerLoginScreen()));
                }, 
                child: Text(
                  "Lawer",
                  style: TextStyle(
                    fontSize: 18
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  primary: Colors.redAccent
                ),
              ),
              ),
                ],
              ),
            ),
            

          ],
        ),
        
      ),
    );
  }
}