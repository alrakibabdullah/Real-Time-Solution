import 'package:flutter/material.dart';
import 'package:new_project/utils/app_color.dart';
import 'package:new_project/view/screens/coine_page.dart';
import 'package:new_project/view/screens/home_first_page.dart';
import 'package:new_project/view/screens/singup_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const homepage(),
    );
  }
}
