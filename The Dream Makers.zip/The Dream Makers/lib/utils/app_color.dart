import 'package:flutter/cupertino.dart';

class AppColor{
  static const Color backgroundColor= Color(0xff16171C);
  static const Color buttonColor=Color(0xffe00847);
  static const Color welo=Color(0xffCB630C);
  static const Color grey=Color(0xff404040);
  static const Color lightgrey=Color(0xff595959);
  static const Color black=Color(0xff000000);
  static const Color white=Color(0xffffffff);
  static const Color loginBackgroundColor=Color(0xff102540);
  static const Color shadowColor=Color(0xff0a182a);
}