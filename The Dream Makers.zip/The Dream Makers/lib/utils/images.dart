class Images {
  static const String logo = "assets/images/logo.jpeg";
  //static const String dimond = "assets/images/dimond.png";
  static const String gold = "assets/images/gold.jpeg";
 // static const String dimond = "assets/images/dimond.jpeg";
  static const String platinum = "assets/images/platinum.jpeg";

}