class Strings{
  static const String firstName='First Name';
  static const String lastName='Last Name';
  static const String address='Address';
  static const String phoneNumber='Phone Number';
  static const String email='Email';
  static const String next='Next';
  static const String buynow='Buy Now';

  static const String proceedtoPay='Proceed To Pay';

  static const String password='Password';




  static const String dimondearn=r'Earn: 2.5$';


  static const String mainBalance='   Main Balance';
  static const String profile='Profile';
  static const String deposit='Deposit';
  static const String addsClick='Adds Click';
  static const String wallet='Wallet';
  static const String transaction='Transaction History';
  static const String logout='Logout';
  static const String date='Date';
  static const String coin='Coin';
  static const String datetime='12/7/22';
  static const String cointext='Silver';
  static const String withdtext=r'$25.00';


  //new Conine page er name
  static const String login='Login';
  static const String singup='Sign Up';
  static const String silver='Silver';
  static const String gold='Gold';
  static const String dimond='Dimond';
  static const String platinum='Platinum';
  static const String silverprice=r'Price: 10$';
  static const String silverearn=r'Earn Per Day:';
  static const String silverdoller=r'Earn: 0.25$';
  static const String earnperday='Earn Per Day:';
  static const String platinumorice=r'Price: 50$';
  static const String platinumdoller=r'1.25';
  static const String goldprice=r'Price: 1.25';
  static const String golddoller=r'0.62$';
  static const String dimondprice=r'Price:100$';
  static const String dimonddoller=r'2.5$';
  static const String minimum='Minimum';
  static const String withdraw=r'Withdraw: 3$';
  static const String withdrawLimit='Withdraw Limit:';
  static const String timesMo='3 times/mo';





}