
import 'dart:ui';
import 'package:flutter/cupertino.dart';
import 'app_color.dart';
import 'dimension.dart';
import 'package:flutter/material.dart';


TextStyle get fontsize30=> TextStyle(fontSize: 30,color: AppColor.white,fontFamily: 'poppins');
TextStyle get fontsize25=> TextStyle(fontSize: 25,color: AppColor.buttonColor,fontFamily: 'poppins');
TextStyle get fontsize25wh=> TextStyle(fontSize: 25,color: AppColor.white,fontFamily: 'poppins');
TextStyle get buttonTextColor=> TextStyle(fontSize: 20,color: AppColor.white,fontFamily: 'poppins');
TextStyle get fontsize20=> TextStyle(fontSize: 20,color: AppColor.buttonColor,fontWeight: FontWeight.bold,fontFamily: 'poppins');
TextStyle get priceTextSize=> TextStyle(fontSize: 16,color: AppColor.white,fontWeight: FontWeight.bold,fontFamily: 'poppins');
TextStyle get transactionTextSize=> TextStyle(fontSize: 20,color: AppColor.white,fontFamily: 'poppins');