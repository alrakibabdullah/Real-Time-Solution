import 'package:flutter/material.dart';
import 'package:new_project/utils/images.dart';
import 'package:new_project/utils/strings.dart';
import 'package:new_project/utils/style.dart';
import 'package:new_project/view/widgets/custom_button.dart';
import '../../utils/app_color.dart';
import 'dashbord.dart';

class coinepage extends StatelessWidget {
  const coinepage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.black,
      appBar: AppBar(
        elevation: 0,
        iconTheme: IconThemeData(color: AppColor.buttonColor,size: 35),
        backgroundColor: AppColor.black,
      ),
      body: SingleChildScrollView(
        child: Container(
          alignment: Alignment.topCenter,
          child: Padding(
            padding: const EdgeInsets.only(top: 5,bottom: 50),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: 620,
                  width: 300,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(40),
                    color: AppColor.backgroundColor,
                  ),
                  child: Column(
                    children: [
                      SizedBox(height: 40,),
                      Icon(Icons.filter_b_and_w,size: 70,color: AppColor.buttonColor,),
                      SizedBox(height: 30,),
                      Text(Strings.silver,style: fontsize30,),
                      SizedBox(height: 30,),
                      Text(Strings.silverprice,style: fontsize25,),
                      Text(Strings.earnperday,style: fontsize25,),
                      Text(Strings.silverdoller,style: fontsize25,),
                      Text(Strings.minimum,style: fontsize25,),
                      Text(Strings.withdraw,style: fontsize25,),
                      Text(Strings.withdrawLimit,style: fontsize25,),
                      Text(Strings.timesMo,style: fontsize25,),
                      SizedBox(height: 40,),
                      CustomBottomNavigation(textData: Strings.buynow,
                          onTap: (){
                            Navigator.push(
                                context, MaterialPageRoute(builder: (ctx) => dashbord()));
                          })
                    ],
                  ),
                ),
                SizedBox(height: 70,),
                Container(
                  height: 620,
                  width: 300,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(40),
                    color: AppColor.backgroundColor,
                  ),
                  child: Column(
                    children: [
                      SizedBox(height: 40,),
                      Icon(Icons.healing,size: 70,color: AppColor.buttonColor,),
                      SizedBox(height: 40,),
                      Text(Strings.gold,style: fontsize30,),
                      SizedBox(height: 30,),
                      Text(Strings.goldprice,style: fontsize25,),
                      Text(Strings.earnperday,style: fontsize25,),
                      Text(Strings.golddoller,style: fontsize25,),
                      Text(Strings.minimum,style: fontsize25,),
                      Text(Strings.withdraw,style: fontsize25,),
                      Text(Strings.withdrawLimit,style: fontsize25,),
                      Text(Strings.timesMo,style: fontsize25,),
                      SizedBox(height: 40,),
                      CustomBottomNavigation(textData: Strings.buynow,onTap: (){
                        Navigator.push(
                            context, MaterialPageRoute(builder: (ctx) => dashbord()));
                      })
                    ],
                  ),
                ),
                SizedBox(height: 70,),
                Container(
                  height: 620,
                  width: 300,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(40),
                    color: AppColor.backgroundColor,
                  ),
                  child: Column(
                    children: [
                      SizedBox(height: 40,),
                      Icon(Icons.dashboard_outlined,size: 70,color: AppColor.buttonColor,),
                      SizedBox(height: 40,),
                      Text(Strings.platinum,style: fontsize30,),
                      SizedBox(height: 30,),
                      Text(Strings.platinumorice,style: fontsize25,),
                      Text(Strings.earnperday,style: fontsize25,),
                      Text(Strings.platinumdoller,style: fontsize25,),
                      Text(Strings.minimum,style: fontsize25,),
                      Text(Strings.withdraw,style: fontsize25,),
                      Text(Strings.withdrawLimit,style: fontsize25,),
                      Text(Strings.timesMo,style: fontsize25,),
                      SizedBox(height: 40,),
                      CustomBottomNavigation(textData: Strings.buynow,onTap: (){
                        Navigator.push(
                            context, MaterialPageRoute(builder: (ctx) => dashbord()));
                      })
                    ],
                  ),
                ),
                SizedBox(height: 70,),
                Container(
                  height: 620,
                  width: 300,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(40),
                    color: AppColor.backgroundColor,
                  ),
                  child: Column(
                    children: [
                       SizedBox(height: 40,),
                      Icon(Icons.diamond,size: 70,color: AppColor.buttonColor,),
                      SizedBox(height: 40,),
                      Text(Strings.dimond,style: fontsize30,),
                      SizedBox(height: 30,),
                      Text(Strings.dimondprice,style: fontsize25,),
                      Text(Strings.earnperday,style: fontsize25,),
                      Text(Strings.dimonddoller,style: fontsize25,),
                      Text(Strings.minimum,style: fontsize25,),
                      Text(Strings.withdraw,style: fontsize25,),
                      Text(Strings.withdrawLimit,style: fontsize25,),
                      Text(Strings.timesMo,style: fontsize25,),
                      SizedBox(height: 40,),
                      CustomBottomNavigation(textData: Strings.buynow,onTap: (){
                        Navigator.push(
                            context, MaterialPageRoute(builder: (ctx) => dashbord()));
                      }),

                    ],
                  ),
                ),
              ],
            ),
          ),
        )
      ),
    );
  }
}






