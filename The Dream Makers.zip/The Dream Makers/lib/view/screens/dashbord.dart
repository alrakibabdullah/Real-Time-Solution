import 'package:flutter/material.dart';
import 'package:new_project/view/screens/singup_screen.dart';
import 'package:new_project/view/screens/transaction_history.dart';

import '../../utils/app_color.dart';
import '../../utils/images.dart';
import '../../utils/strings.dart';
import '../../utils/style.dart';
import 'login_screen.dart';





class dashbord extends StatelessWidget {
  const dashbord({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.loginBackgroundColor,
      appBar: AppBar(
         iconTheme: IconThemeData(color: AppColor.buttonColor,size: 35),
        backgroundColor: AppColor.loginBackgroundColor,
        elevation: 0,

      ),
      body:Container(
        //alignment: Alignment.topCenter,
        child: Column(
          children: [
            SizedBox(height: 60,),
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    MainBalance(),
                    SizedBox(width: 30,),
                    Deposit()
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
      drawer: Drawer(
          backgroundColor: AppColor.loginBackgroundColor,
          width: 200,
          child: Padding(
            padding: const EdgeInsets.only(top: 40),
            child: Column(
              children: [
                ClipOval(
                  child:  Image.asset(Images.logo,
                    height: 80,
                    width: 80,
                  ),
                ),
                SizedBox(height: 20,),
                DrawerItems(ItemsData: Strings.mainBalance),
                SizedBox(height: 20,),
                DrawerItems(ItemsData: Strings.profile),
                SizedBox(height: 20,),
                DrawerItems(ItemsData: Strings.addsClick),
                SizedBox(height: 20,),
                DrawerItems(ItemsData: Strings.wallet),
                SizedBox(height: 20,),
                TranSactionButton(tranSactionText: Strings.transaction,),
                SizedBox(height: 20,),
                DrawerItems(ItemsData: Strings.logout)
              ],
            ),
          )
      ),

    );

  }
}




//Drawer List or Items




class DrawerItems extends StatelessWidget {
  final String ItemsData;

  const DrawerItems({Key? key, required this.ItemsData}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      width: 180,
      decoration: BoxDecoration(
          color: AppColor.buttonColor,
        borderRadius: BorderRadius.circular(10)
      ),
      child: Center(child: Text(ItemsData,style: priceTextSize,)),
    );
  }
}







class MainBalance extends StatelessWidget {

  const MainBalance({Key? key,  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 80,
      width: 120,
      decoration: BoxDecoration(

          boxShadow: [
            BoxShadow(
                color: AppColor.shadowColor,
                blurRadius: 1,
                spreadRadius: 1,
                offset: Offset(10,10)
            ),
          ],
          borderRadius: BorderRadius.circular(20),
          color: AppColor.buttonColor
      ),
      child: MaterialButton(
        onPressed: (){
         // Navigator.push(context, MaterialPageRoute(builder: (ctx)=>singupScreen()));
        },
        child: Center(child: Text(Strings.mainBalance,style: buttonTextColor,)),
      ),
    );
  }
}


class Deposit extends StatelessWidget {

  const Deposit({Key? key,  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 80,
      width: 120,
      decoration: BoxDecoration(

          boxShadow: [
            BoxShadow(
                color: AppColor.shadowColor,
                blurRadius: 1,
                spreadRadius: 1,
                offset: Offset(10,10)
            ),
          ],
          borderRadius: BorderRadius.circular(20),
          color: AppColor.buttonColor
      ),
      child: MaterialButton(
        onPressed: (){
        //  Navigator.push(context, MaterialPageRoute(builder: (ctx)=>loginScreen()));
        },
        child: Center(child: Text(Strings.deposit,style: buttonTextColor,)),
      ),
    );
  }
}
