
import 'package:flutter/material.dart';
import 'package:new_project/utils/images.dart';
import 'package:new_project/view/screens/dashbord.dart';
import 'package:new_project/view/screens/login_screen.dart';
import 'package:new_project/view/screens/singup_screen.dart';
import '../../utils/app_color.dart';
import 'package:flutter/material.dart';

import '../../utils/strings.dart';
import '../../utils/style.dart';
import 'home_first_page.dart';

class homepage extends StatelessWidget {
  const homepage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.loginBackgroundColor,
      appBar: AppBar(
        // iconTheme: IconThemeData(color: AppColor.black,size: 35),
        backgroundColor: AppColor.loginBackgroundColor,
        elevation: 0,

      ),
      body:Center(
        child: Container(
          //alignment: Alignment.topCenter,
          child: Column(
            children: [
              ClipOval(
                child: Image.asset(Images.logo,
                  height: 120,
                  width: 120,
                  fit: BoxFit.cover,
                ),
              ),
              SizedBox(height: 80,),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SignUpButton(),
                      SizedBox(height: 30,),
                      LoginButton()
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),

    );

  }
}



//SingUp Button for This Page



class SignUpButton extends StatelessWidget {

  const SignUpButton({Key? key,  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 80,
      width: 170,
      decoration: BoxDecoration(

          boxShadow: [
            BoxShadow(
                color: AppColor.shadowColor,
                blurRadius: 1,
                spreadRadius: 1,
                offset: Offset(10,10)
            ),
          ],
          borderRadius: BorderRadius.circular(20),
          color: AppColor.buttonColor
      ),
      child: MaterialButton(
        onPressed: (){
          Navigator.push(context, MaterialPageRoute(builder: (ctx)=>singupScreen()));
        },
        child: Center(child: Text(Strings.singup,style: buttonTextColor,)),
      ),
    );
  }
}



//Login Button for This Page


class LoginButton extends StatelessWidget {

  const LoginButton({Key? key,  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 80,
      width: 170,
      decoration: BoxDecoration(

          boxShadow: [
            BoxShadow(
                color: AppColor.shadowColor,
                blurRadius: 1,
                spreadRadius: 1,
                offset: Offset(10,10)
            ),
          ],
          borderRadius: BorderRadius.circular(20),
          color: AppColor.buttonColor
      ),
      child: MaterialButton(
        onPressed: (){
          Navigator.push(context, MaterialPageRoute(builder: (ctx)=>loginScreen()));
        },
        child: Center(child: Text(Strings.login,style: buttonTextColor,)),
      ),
    );
  }
}
