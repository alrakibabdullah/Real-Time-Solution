
import 'package:flutter/material.dart';
import 'package:new_project/view/screens/dashbord.dart';

import '../../../utils/strings.dart';
import '../../../utils/style.dart';
import '../../utils/app_color.dart';
import '../../utils/images.dart';
import '../widgets/custom_textField.dart';
import 'coine_page.dart';

class loginScreen extends StatelessWidget {
  const loginScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.loginBackgroundColor,
      appBar: AppBar(
       toolbarHeight: 0,
        backgroundColor: AppColor.loginBackgroundColor,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(top: 30),
          child: Container(
            alignment: Alignment.topCenter,
            child: Column(
              children: [
                ClipOval(
                  child: Image.asset(Images.logo,
                    height: 120,
                    width: 120,
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(height: 60,),
                SizedBox(height: 20,),
                CustomTextField( data: Strings.email),
                SizedBox(height: 30,),
                CustomTextField( data: Strings.password),
                SizedBox(height: 100,),
                CustomLoginButton(textData: Strings.login,)
              ],

            ),
          ),
        ),
      ),
    );
  }
}


class CustomLoginButton extends StatelessWidget {
  final String textData;
  const CustomLoginButton({  Key? key, required this.textData,})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 60,
      width: 150,
      decoration: BoxDecoration(

          borderRadius: BorderRadius.circular(10),
          color: AppColor.buttonColor
      ),
      child: MaterialButton(
        onPressed: (){
          Navigator.push(context, MaterialPageRoute(builder: (ctx)=>dashbord()));
        },
        child: Text(textData,style: buttonTextColor),
      ),
    );
  }
}

