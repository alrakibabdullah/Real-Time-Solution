import 'package:flutter/material.dart';

import '../../utils/app_color.dart';
import '../../utils/images.dart';
import '../../utils/strings.dart';
import '../../utils/style.dart';
import '../widgets/custom_button.dart';
import '../widgets/custom_textField.dart';
import 'coine_page.dart';

class singupScreen extends StatelessWidget {
  const singupScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.loginBackgroundColor,
      appBar: AppBar(
        backgroundColor: AppColor.loginBackgroundColor,
        toolbarHeight: 0,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(top: 30),
          child: Container(
            alignment: Alignment.topCenter,
            child: Column(
              children: [
                ClipOval(
                  child: Image.asset(
                    Images.logo,
                    height: 120,
                    width: 120,
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(height: 20,),
                CustomTextField(data: Strings.firstName),
                SizedBox(height: 20),
                CustomTextField(data: Strings.lastName),
                SizedBox(height: 20,),
                CustomTextField(data: Strings.address),
                SizedBox(height: 20,),
                CustomTextField(data: Strings.phoneNumber),
                SizedBox(height: 20,),
                CustomTextField(data: Strings.email),
                SizedBox(height: 20,),
                CustomSingupButton(
                  textData: Strings.next,
                ),
                SizedBox(
                  height: 20,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class CustomSingupButton extends StatelessWidget {
  final String textData;

  const CustomSingupButton({
    Key? key,
    required this.textData,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 60,
      width: 150,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10), color: AppColor.buttonColor),
      child: MaterialButton(
        onPressed: () {
          Navigator.push(
              context, MaterialPageRoute(builder: (ctx) => coinepage()));
        },
        child: Text(textData, style: buttonTextColor),
      ),
    );
  }
}
