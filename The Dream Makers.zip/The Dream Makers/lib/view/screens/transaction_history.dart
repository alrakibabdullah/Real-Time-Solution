
import 'package:flutter/material.dart';
import 'package:new_project/view/widgets/custom_button.dart';

import '../../utils/app_color.dart';
import '../../utils/strings.dart';
import '../../utils/style.dart';
import 'dashbord.dart';

class transactionHistory extends StatelessWidget {
  const transactionHistory({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.loginBackgroundColor,
      appBar: AppBar(
        iconTheme: IconThemeData(color: AppColor.buttonColor,size: 35),
        backgroundColor: AppColor.loginBackgroundColor,
        title: Center(child: Text('Transaction history')),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(top:20,right: 20,left: 20,),
          child: Center(
            child: Container(
              height: 620,
              width: 330,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(40),
                color: AppColor.loginBackgroundColor,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    children: [
                      Text(Strings.date,style: priceTextSize,),
                      Padding(
                        padding: const EdgeInsets.only(top: 15),
                        child: Text(Strings.datetime,style: transactionTextSize,),
                      ),
                      SizedBox(height: 20,),
                      Text(Strings.datetime,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      Text(Strings.datetime,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      Text(Strings.datetime,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      Text(Strings.datetime,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      Text(Strings.datetime,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      Text(Strings.datetime,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      Text(Strings.datetime,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      Text(Strings.datetime,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      Text(Strings.datetime,style: transactionTextSize,),
                      SizedBox(height: 20,),
                    ],
                  ),
                  Column(
                    children: [
                      Text(Strings.coin,style: priceTextSize,),
                      Padding(
                        padding: const EdgeInsets.only(top: 15),
                        child: Text(Strings.cointext,style: transactionTextSize,),
                      ),
                      SizedBox(height: 20,),
                      Text(Strings.cointext,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      Text(Strings.cointext,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      Text(Strings.cointext,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      Text(Strings.cointext,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      Text(Strings.cointext,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      Text(Strings.cointext,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      Text(Strings.cointext,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      Text(Strings.cointext,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      Text(Strings.cointext,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      CustomBottomNavigation(textData: Strings.next,onTap: (){
                        Navigator.push(
                            context, MaterialPageRoute(builder: (ctx) => dashbord()));
                      })


                    ],
                  ),
                  Column(
                    children: [
                      Text(Strings.withdraw,style: priceTextSize,),
                      Padding(
                        padding: const EdgeInsets.only(top: 15),
                        child: Text(Strings.withdtext,style: transactionTextSize,),
                      ),
                      SizedBox(height: 20,),
                      Text(Strings.withdtext,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      Text(Strings.withdtext,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      Text(Strings.withdtext,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      Text(Strings.withdtext,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      Text(Strings.withdtext,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      Text(Strings.withdtext,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      Text(Strings.withdtext,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      Text(Strings.withdtext,style: transactionTextSize,),
                      SizedBox(height: 20,),
                      Text(Strings.withdtext,style: transactionTextSize,),
                      SizedBox(height: 20,),

                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      )
    );
  }
}






class TranSactionButton extends StatelessWidget {

  final  String tranSactionText;
  const TranSactionButton({Key? key, required this.tranSactionText, }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: (){
        Navigator.push(context, MaterialPageRoute(builder: (ctx)=>transactionHistory()));
      },
      child: Container(
        height: 40,
        width: 180,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: AppColor.buttonColor,
        ),
        child: Center(child: Text(tranSactionText,style: priceTextSize,)),
      ),
    );
  }
}

