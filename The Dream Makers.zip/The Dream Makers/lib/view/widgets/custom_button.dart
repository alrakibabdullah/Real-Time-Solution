
import 'package:flutter/material.dart';
import 'package:new_project/view/screens/coine_page.dart';
import 'package:new_project/view/screens/dashbord.dart';

import '../../utils/app_color.dart';
import '../../utils/style.dart';


class CustomBottomNavigation extends StatelessWidget {
  final String textData;
  final VoidCallback? onTap;


  const CustomBottomNavigation({  Key? key, required this.textData, this.onTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        height: 60,
        width: 150,
        alignment: Alignment.center,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: AppColor.buttonColor
        ),
        child: Center(
          child: MaterialButton(
            onPressed: onTap,
            child: Center(child: Center(child: Text(textData,style: buttonTextColor))),
          ),
        ),
      ),
    );
  }
}



