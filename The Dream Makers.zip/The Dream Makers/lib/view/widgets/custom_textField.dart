import 'package:flutter/material.dart';
import 'package:new_project/utils/dimension.dart';

import '../../utils/app_color.dart';
import '../../utils/style.dart';

class CustomTextField extends StatelessWidget {
  final String data;
  const CustomTextField({Key? key, required this.data}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        height: 60,
        width:300,
        decoration: BoxDecoration(
            color: AppColor.lightgrey,
                borderRadius: BorderRadius.circular(20)
        ),
        child: Column(
          children: [
            TextField(
              textAlign: TextAlign. center,
              cursorColor: AppColor.black,
              decoration: InputDecoration(
                  border: InputBorder.none,
                  hintText: (data),
                  hintStyle:buttonTextColor
              ),
            )
          ],
        ),
    );
  }
}
