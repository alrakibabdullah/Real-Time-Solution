<?php

namespace App\Enums;

interface Constant
{
    CONST USER_STATUS_ACTIVE = 1;
    CONST USER_STATUS_DEACTIVE = 0;
}
