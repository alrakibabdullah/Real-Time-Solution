 
 
<?php $__env->startSection('content'); ?>
  
 <div class="card mb-4">
    <div class="card-body">
        <div class="d-flex justify-content-between">
            <div>
                <h4 class="card-title mb-0" style="color: black"> Premium Subscription To User</h4>
            </div>
            <div>
                
            </div>
        </div>
        <div style="margin-top: 40px;">
            <table class="table">
                <thead>
                    <tr>
                        <th style="width: 10%;">#</th>
                        <th style="width: 15%;">User Name</th>
                        <th style="width: 15%;">Subscription Name</th>
                        <th style="width: 15%;">activated_at</th>
                        <th style="width: 15%;">deactivated_at</th>
                        <th style="width: 15%;">free_days</th>
                        <th style="width: 15%;">free_day</th>
                      
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $premium_sub_to_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($data->id); ?></td>
                        <td><?php echo e($data->user_name); ?></td>
                        <td><?php echo e($data->name); ?></td>
                        <td><?php echo e($data->activated_at); ?></td>
                        <td><?php echo e($data->deactivated_at); ?></td>
                        <td><?php echo e($data->free_days); ?></td>
                        <td> <select> 
                          <option value="">  <?php echo e(explode(",", $data->free_day)[0]); ?> Days</option>
                            <option> <?php echo e(explode(",", $data->free_day)[1]); ?> Days</option>
                            <option> <?php echo e(explode(",", $data->free_day)[2]); ?> Days</option>
                            <option> <?php echo e(explode(",", $data->free_day)[3]); ?> Days</option>
                            <option> <?php echo e(explode(",", $data->free_day)[4]); ?> Days</option>
                        </select>
                        

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\tag_vpn\resources\views/admin/premium-sub-to-user.blade.php ENDPATH**/ ?>