<?php if($success = Session::get('success')): ?>
<div class="alert success fade show mi-smart-alert" role="alert">
    <p><?php echo e($success); ?>

        <button type="button" class="btn-close ps-3" data-bs-dismiss="alert" aria-label="Close"></button>
    </p>
</div>
<?php endif; ?>

<?php if($warning = Session::get('warning')): ?>
<div class="alert warning fade show mi-smart-alert" role="alert">
    <p><?php echo e($warning); ?>

        <button type="button" class="btn-close ps-3" data-bs-dismiss="alert" aria-label="Close"></button>
    </p>
</div>
<?php endif; ?>

<?php if($error = Session::get('error')): ?>
<div class="alert danger fade show mi-smart-alert" role="alert">
    <p><?php echo e($error); ?>

        <button type="button" class="btn-close ps-3" data-bs-dismiss="alert" aria-label="Close"></button>
    </p>
</div>
<?php endif; ?>

<?php if($errors->any()): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="alert danger fade show mi-smart-alert" role="alert">
    <p><?php echo e($error); ?>

        <button type="button" class="btn-close ps-3" data-bs-dismiss="alert" aria-label="Close"></button>
    </p>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\project\tag_vpn\resources\views/theme/toaster.blade.php ENDPATH**/ ?>