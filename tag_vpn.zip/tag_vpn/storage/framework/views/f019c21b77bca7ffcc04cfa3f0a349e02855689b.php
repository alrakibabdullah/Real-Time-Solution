<ul>
    <?php $__currentLoopData = sideMenu(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <?php if(isset($item['children'])): ?>
        <a class="dropdown"><i class="<?php echo e($item['icon']); ?>"></i><span class="title"><?php echo e($item['title']); ?></span></a>
        <ul class="submenu collapse">
            <?php $__currentLoopData = $item['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $children): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="<?php echo e(isActive($children['url'])); ?>"><a href="<?php echo e('/'.$children['url']); ?>"><i></i><i class="<?php echo e($children['icon']); ?>"></i> <span><?php echo e($children['title']); ?></span> </a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php else: ?>
        <a href="<?php echo e('/'.$item['url']); ?>" class="<?php echo e((Request::is($item['url'],$item['url'].'/edit/*') ? 'main-active' : '')); ?> single-item"><i class="<?php echo e($item['icon']); ?>"></i><span class="title"><?php echo e($item['title']); ?></span></a>
        <?php endif; ?>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ul>
<?php /**PATH C:\xampp\htdocs\project\tag_vpn\resources\views/theme/sidebar.blade.php ENDPATH**/ ?>